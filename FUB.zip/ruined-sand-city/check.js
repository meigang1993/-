const fs = require('fs');
const path = require('path');
const vm = require('vm');

const dir = path.join(__dirname, 'src/original');
const files = fs.readdirSync(dir).filter(f => f.endsWith('.js')).sort();

console.log('=== 废墟沙城静态检查 ===\n');
let errors = 0;

// 1. 行数检查（≤200）
console.log('1. 行数检查 (上限200行):');
for (const f of files) {
  const lines = fs.readFileSync(path.join(dir, f), 'utf8').split('\n').length;
  const flag = lines > 200 ? '❌' : '✅';
  if (lines > 200) errors++;
  console.log(`  ${flag} ${f}: ${lines} 行`);
}

// 2. 语法检查（用 vm 解析，不执行 DOM 依赖）
console.log('\n2. 语法检查:');
for (const f of files) {
  const code = fs.readFileSync(path.join(dir, f), 'utf8');
  try {
    new vm.Script(code, { filename: f });
    console.log(`  ✅ ${f}`);
  } catch (e) {
    console.log(`  ❌ ${f}: ${e.message}`);
    errors++;
  }
}

// 3. ruins-common.js 存在性 + 自检守卫（加载顺序由 HTML/构建决定，此处仅确认其存在且被正确引用）
console.log('\n3. ruins-common 自检守卫检查:');
const commonFile = 'ruins-common.js';
const code = fs.readFileSync(path.join(dir, commonFile), 'utf8');
const ok = code.includes('__RUINS_COMMON_LOADED');
console.log(`  ${ok ? '✅' : '❌'} ${commonFile} 设置 __RUINS_COMMON_LOADED`);
if (!ok) errors++;

// 4. 每个 monster 文件都引用了 __RUINS_COMMON_LOADED 自检
console.log('\n4. 自检守卫检查 (monster/card/accessory 文件):');
const guarded = files.filter(f => f.startsWith('monster-') || f.startsWith('cards-') || f.startsWith('accessories-'));
for (const f of guarded) {
  const code = fs.readFileSync(path.join(dir, f), 'utf8');
  const ok = code.includes('__RUINS_COMMON_LOADED');
  console.log(`  ${ok ? '✅' : '❌'} ${f}`);
  if (!ok) errors++;
}

// 5. 全局命名空间导出检查
console.log('\n5. 全局命名空间导出:');
const expectedGlobals = [
  'ruins-common.js:RuinsCommon',
  'dungeon-ruined-sand-city.js:RuinedSandCity',
  'monster-fae-soldier.js:FaeSoldierSkills',
  'monster-noble-sniper.js:NobleSniperSkills',
  'monster-melkar-tank.js:MelkarTankSkills',
  'monster-attack-drone.js:AttackDroneSkills',
  'monster-mech-ai-dragon.js:MechAiDragonSkills',
  'monster-wither-unit-1312.js:WitherUnit1312Skills',
  'monster-assassin-hilde.js:AssassinHildeSkills',
  'monster-attack-helicopter.js:AttackHelicopterSkills',
  'monster-armored-transport.js:ArmoredTransportSkills',
  'monster-attack-drone.js:AttackDroneSkills',
  'cards-ruined-sand-city.js:RuinedSandCityCards',
  'accessories-ruined-sand-city.js:RuinedSandCityAccessories'
];
for (const eg of expectedGlobals) {
  const [file, global] = eg.split(':');
  const code = fs.readFileSync(path.join(dir, file), 'utf8');
  const ok = code.includes(`window.${global}`) || code.includes(`window.${global} =`);
  console.log(`  ${ok ? '✅' : '❌'} ${global}`);
  if (!ok) errors++;
}

// 6.  ASCII 文件名检查
console.log('\n6. ASCII 文件名检查:');
const asciiRe = /^[a-z0-9.\-_]+$/;
for (const f of files) {
  const ok = asciiRe.test(f);
  console.log(`  ${ok ? '✅' : '❌'} ${f}`);
  if (!ok) errors++;
}

console.log(`\n=== 结果: ${errors === 0 ? '全部通过 ✅' : `${errors} 个错误 ❌`} ===`);
process.exit(errors ? 1 : 0);
