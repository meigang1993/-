# 废墟沙城副本 - 接入说明

## 文件清单（扁平结构，全部放 `src/original/`，无子文件夹）

```
src/original/
├── README.md                            # 本文件
├── ruins-common.js                      # ⚠️ 必须第一个加载（工具+状态牌）
├── dungeon-ruined-sand-city.js          # 副本配置（15层/篝火/宝箱/怪物池/掉落）
├── monster-fae-soldier.js               # 贵族军士兵 - 放置地雷
├── monster-noble-sniper.js              # 贵族军狙击手 - 狙击目标
├── monster-melkar-tank.js               # 梅尔卡坦克 - 坦克炮弹
├── monster-attack-drone.js              # 攻击型无人机 - 麻痹毒子弹
├── monster-mech-ai-dragon.js            # 机械AI龙（领主）- 电钻火花/机尾机枪/死亡音波
├── monster-wither-unit-1312.js          # XX型凋零者1312号（领主）- 外神之眼/魅魔吸精术/百眼魅魔
├── monster-assassin-hilde.js            # 内英组杀手希尔德 - 暗幕隐身/影舞步/潜影背刺
├── monster-attack-helicopter.js         # 武装直升机 - 战场扫射/继续压制
├── monster-armored-transport.js         # 装甲运输车 - 无脑冲撞/坚硬装甲/增援部队
├── cards-ruined-sand-city.js            # 10张掉落卡牌
└── accessories-ruined-sand-city.js      # 10个掉落饰品
```

## 接入步骤

### 1. 部署文件
将上面 13 个 `.js` 直接拷到项目 `src/original/`（与 `app.js`、`abe-mike-skills.js` 并列）。

### 2. 注册加载（二选一）

**A. 若入口是 HTML `<script>` 标签**（在 `app.js` 之后追加）：
```html
<script src="src/original/ruins-common.js"></script>
<script src="src/original/dungeon-ruined-sand-city.js"></script>
<script src="src/original/monster-fae-soldier.js"></script>
<script src="src/original/monster-noble-sniper.js"></script>
<script src="src/original/monster-melkar-tank.js"></script>
<script src="src/original/monster-attack-drone.js"></script>
<script src="src/original/monster-mech-ai-dragon.js"></script>
<script src="src/original/monster-wither-unit-1312.js"></script>
<script src="src/original/monster-assassin-hilde.js"></script>
<script src="src/original/monster-attack-helicopter.js"></script>
<script src="src/original/monster-armored-transport.js"></script>
<script src="src/original/cards-ruined-sand-city.js"></script>
<script src="src/original/accessories-ruined-sand-city.js"></script>
```

**B. 若用打包构建**：把 13 个文件加入 `build-publish-bundles.js` 入口，自动合并到 `startup-app.min.js`。

### 3. 接口对接（重要）
所有怪物/卡牌/饰品通过 `context.xxx` 调用战斗系统。需对照你现有 `BattleSystem` 对齐以下方法名：

**必须实现的核心接口**
- 角色：`getStat / takeDamage / addCard / setHand / drawCards / discardCards / gainArmor / loseHp / judgeCard / revive`
- 手牌：`hand / getCardsBySuit / countSuitInHand / countResponseCards / selectHandCards / findSameSuitPair / hasBlackCard / removeCard`
- 目标：`getEnemies / getAllies / getDeadAllies / chooseTarget / randomEnemy`
- 标记：`hasUsedSkill / markSkillUsed / setFlag / getFlag / clearFlag / setSkipPlay`
- 伤害：`dealDamage / applyDamage / applyMark / setUnresponseable / isDamageImmune`
- 卡牌：`useAsKill / useAsSkillKill / autoUseCard / stealRandomCard / discardRandomCard / tryUseKill / tryUseTactical`
- 回合钩子：`onPlayPhase / onPreparePhase / onEndPhase / onDamaged / onKillDamageDealt / onKillEvaded / onTacticalDamageDealt / onResponseUsed / onEnemyPlayPhase / onAIAction / onCardAcquired`

### 4. 状态牌判定
`RuinsCommon.resolveStatusCards(target, phase)` 需在判定阶段由 `BattleSystem` 调用，处理：
- 麻痹（♥/♠ → 无法用牌）
- 混乱（♠/♥ → 随机攻击己方）
- 冰冻（♦/♣ → 无法用杀）
- 地雷（使用/打出响应牌时受伤，见 `FaeSoldierSkills.onResponseUsed`）

### 5. 更新资产清单
把 `assets/ruined-sand-city/*.png` 和 `*.mp3` 注册到 `asset-manifest.json`（沿用之前讨论的命名）。

## 验证
1. 打开浏览器控制台，确认无 `window.__RUINS_COMMON_LOADED` 报错。
2. 参考 `dungeon-flow.js` 写 Playwright 测试，固定种子 `2971485`。
3. 逐怪物验证技能触发，重点：1312号混乱/百眼魅魔、装甲车增援、直升机战场扫射。
