// 武装直升机（精英）- 战场扫射 / 继续压制
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const SKILL = 'battlefield-sweep';
  const D = window.RuinsCommon;

  window.AttackHelicopterSkills = {
    id: 'attack-helicopter',
    displayName: '武装直升机',
    baseStats: { attack: 9, magic: 8, speed: 12, hp: 210, maxRage: 1, maxHand: 5, drawPerTurn: 5, initDraw: 6 },

    // ⚔️ 战场扫射：出牌阶段将2张同花色牌当做机枪扫杀使用，不消耗杀意
    onPlayPhase: function (context) {
      if (context.hasUsedSkill(this.id, SKILL)) return;
      const pair = context.findSameSuitPair(context.self);
      if (!pair) return;
      context.useAsSkillKill('machine-gun-sweep', { cards: pair, allEnemies: true, freeRage: true });
      context.markSkillUsed(this.id, SKILL);
      context.log('战场扫射！');
    },

    // ⭐ 继续压制（锁定技）：杀被闪抵消时，摸1张牌
    onKillEvaded: function (context, target) {
      context.self.drawCards(1);
      context.log('继续压制：摸1张牌。');
    },

    // AI：优先战场扫射，再使用其他杀牌
    onAIAction: function (context) {
      this.onPlayPhase(context);
      context.tryUseKill({ single: false });
    }
  };
})();
