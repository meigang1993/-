// 机械AI龙（领主）- 电钻火花 / 机尾机枪 / 死亡音波
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const D = window.RuinsCommon;
  const FLAG_RECORDED = 'dragonRecordedSuits';

  window.MechAiDragonSkills = {
    id: 'mech-ai-dragon',
    displayName: '机械AI龙',
    baseStats: { attack: 13, magic: 8, speed: 15, hp: 342, maxRage: 1, maxHand: 4, drawPerTurn: 4, initDraw: 5 },

    // 🔵 电钻火花：单体杀造成伤害时，摇骰子按点数增加额外攻击次数
    onKillDamageDealt: function (context, target, damage) {
      if (!context.isSingleKill(damage.card)) return;
      const roll = context.rollDie();
      for (let i = 0; i < roll; i++) {
        D.dealDamage(context.self, target, context.self.getStat('attack'), { attr: 'physical' });
      }
      context.log('电钻火花：骰子 ' + roll + ' 点，额外攻击 ' + roll + ' 次');
    },

    // ⭐ 机尾机枪（锁定技）：敌方出牌阶段，当我方受到攻击次数达手牌数时，
    // 对敌方使用机枪扫杀，根据造成伤害获得等量护甲
    onEnemyPlayPhase: function (context, enemy) {
      const attacks = context.getAttackCountOnSelf(this.id);
      if (attacks < context.self.hand.length) return;
      const sweepDmg = context.useSkillKill('machine-gun-sweep', { allEnemies: true });
      if (sweepDmg > 0) context.self.gainArmor(sweepDmg);
      context.log('机尾机枪：扫射造成 ' + sweepDmg + ' 伤害，获得 ' + sweepDmg + ' 护甲');
    },

    // 🔵 死亡音波：结束阶段记录手中任意张牌的花色；敌方回合若未使用该花色，回合结束时受伤
    onEndPhase: function (context) {
      const cards = context.selectHandCards(context.self, null, {}); // null=任意张
      const suits = (cards || []).map(function (c) { return c.suit; });
      context.setFlag(this.id, FLAG_RECORDED, suits);
      context.log('死亡音波：记录了花色 ' + suits.map(function (s) { return D.suitName[s]; }).join('、'));
    },

    // 敌方回合结束时检查是否使用了记录的花色（由 BattleSystem 在回合结束钩子调用）
    checkDeathSoundwave: function (context, enemy) {
      const suits = context.getFlag(this.id, FLAG_RECORDED) || [];
      if (!suits.length) return;
      const used = context.getUsedSuits(enemy);
      const missing = suits.some(function (s) { return used.indexOf(s) < 0; });
      if (missing) {
        const dmg = context.self.getStat('attack');
        D.dealDamage(context.self, enemy, dmg);
        context.log('死亡音波：' + enemy.displayName + ' 未使用记录花色，受到 ' + dmg + ' 伤害');
      }
      context.clearFlag(this.id, FLAG_RECORDED);
    }
  };
})();
