// 贵族军狙击手 - 狙击目标
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const SKILL = 'snipe-target';
  const D = window.RuinsCommon;

  window.NobleSniperSkills = {
    id: 'noble-sniper',
    displayName: '贵族军狙击手',
    gender: 'male',
    baseStats: { attack: 14, magic: 9, speed: 15, hp: 58, maxRage: 1, maxHand: 4, drawPerTurn: 3, initDraw: 5 },

    // ⚔️ 狙击目标：出牌阶段限一次
    // 指定敌方一名角色，展示其一张手牌；若我方该花色牌数 > 目标，则后续单体杀目标不可响应
    onPlayPhase: function (context) {
      if (context.hasUsedSkill(this.id, SKILL)) return;
      const target = context.chooseTarget(this.id, { enemiesOnly: true, single: true });
      if (!target) return;
      const shown = context.showRandomHandCard(target, context.self);
      if (!shown) return;

      const myCount = context.countSuitInHand(context.self, shown.suit);
      const tgtCount = context.countSuitInHand(target, shown.suit);
      if (myCount > tgtCount) {
        context.setFlag(target, 'snipedSuit', shown.suit);
        context.setUnresponseable(target, { source: this.id, suit: shown.suit });
        context.log('狙击目标：锁定花色 ' + D.suitName[shown.suit]);
      }
      context.markSkillUsed(this.id, SKILL);
      context.log('让我看看敌人在哪。');
    },

    // AI：对发动技能的角色优先蓄力+单体杀或直接单体杀
    onAIAction: function (context) {
      // 优先发动技能（若未用过）
      if (!context.hasUsedSkill(this.id, SKILL)) this.onPlayPhase(context);
      // 然后使用单体杀
      context.tryUseKill({ single: true });
    }
  };
})();
