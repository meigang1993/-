// 废墟沙城 - 掉落卡牌（别墅商店解锁，1200~1700莉莉丝元）
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const D = window.RuinsCommon;

  // card.context 接口：owner(使用者), targets, amount, log
  const cards = {

    // === 机械AI龙 掉落 ===
    'pin-sha': {
      id: 'pin-sha', displayName: '拼杀', type: 'kill', cost: 1200, source: 'mech-ai-dragon',
      effect: '指定敌方角色造成攻击力伤害。若你的杀牌数>目标，此杀不可响应。',
      onUse: function (ctx) {
        const target = ctx.targets[0];
        const myKills = ctx.countKills(ctx.owner);
        if (myKills > ctx.countKills(target)) ctx.setUnresponseable(target);
        ctx.dealDamage(ctx.owner, target, ctx.owner.getStat('attack'), { attr: 'physical' });
      }
    },
    'mo-zhi-lian-sha': {
      id: 'mo-zhi-lian-sha', displayName: '魔之连杀', type: 'kill', cost: 1400, source: 'mech-ai-dragon',
      effect: '指定敌方角色造成魔力伤害，根据杀牌数额外随机指定目标。',
      onUse: function (ctx) {
        const target = ctx.targets[0];
        ctx.dealDamage(ctx.owner, target, ctx.owner.getStat('magic'), { attr: 'magic' });
        const extra = ctx.countKills(ctx.owner);
        const others = ctx.getOtherEnemies(target);
        for (let i = 0; i < Math.min(extra, others.length); i++) {
          ctx.dealDamage(ctx.owner, others[i], ctx.owner.getStat('magic'), { attr: 'magic' });
        }
      }
    },

    // === XX型凋零者1312号 掉落 ===
    'mei-huo-shu': {
      id: 'mei-huo-shu', displayName: '魅惑术', type: 'obstacle', cost: 1200, source: 'wither-unit-1312',
      effect: '指定敌方一名角色，使其手牌区生成一张混乱状态牌。',
      onUse: function (ctx) {
        D.addStatusCard(ctx.targets[0], D.StatusType.CONFUSION, ctx.owner);
      }
    },
    'mei-sha': {
      id: 'mei-sha', displayName: '魅杀', type: 'kill', cost: 1400, source: 'wither-unit-1312',
      effect: '指定敌方角色造成魔力魔法伤害，并施加脆弱标记（受伤+50%）。',
      onUse: function (ctx) {
        const target = ctx.targets[0];
        ctx.dealDamage(ctx.owner, target, ctx.owner.getStat('magic'), { attr: 'magic' });
        ctx.applyMark(target, 'fragile', { source: 'mei-sha', multiplier: 1.5 });
      }
    },

    // === 内英组杀手希尔德 掉落 ===
    'tou-xi': {
      id: 'tou-xi', displayName: '偷袭', type: 'response', cost: 1100, source: 'assassin-hilde',
      effect: '敌方使用战术牌后，对其造成攻击力物理伤害。',
      onTrigger: function (ctx) {
        if (!ctx.isTacticalPlay) return;
        ctx.dealDamage(ctx.owner, ctx.enemy, ctx.owner.getStat('attack'), { attr: 'physical' });
      }
    },
    'bing-dong-shu': {
      id: 'bing-dong-shu', displayName: '冰冻术', type: 'obstacle', cost: 1500, source: 'assassin-hilde',
      effect: '指定敌方角色生成冰冻状态牌，判定♦或♣则本回合无法使用杀。',
      onUse: function (ctx) {
        D.addStatusCard(ctx.targets[0], D.StatusType.FREEZE, ctx.owner);
      }
    },

    // === 武装直升机 掉落 ===
    'liu-xing-sha': {
      id: 'liu-xing-sha', displayName: '流星杀', type: 'kill', cost: 1200, source: 'attack-helicopter',
      effect: '指定所有敌方角色造成魔力魔法伤害。',
      onUse: function (ctx) {
        const dmg = ctx.owner.getStat('magic');
        ctx.getEnemies().forEach(function (e) { ctx.dealDamage(ctx.owner, e, dmg, { attr: 'magic' }); });
      }
    },
    'xi-mo-sha': {
      id: 'xi-mo-sha', displayName: '吸魔杀', type: 'kill', cost: 1600, source: 'attack-helicopter',
      effect: '指定敌方角色造成魔力魔法伤害，伤害后获得其1张牌。',
      onUse: function (ctx) {
        const target = ctx.targets[0];
        ctx.dealDamage(ctx.owner, target, ctx.owner.getStat('magic'), { attr: 'magic' });
        const card = ctx.stealRandomCard(target);
        if (card) ctx.addCard(ctx.owner, card);
      }
    },

    // === 装甲运输车 掉落 ===
    'wu-zi-si-fen': {
      id: 'wu-zi-si-fen', displayName: '物资私分', type: 'consumable', cost: 1700, source: 'armored-transport',
      effect: '指定我方其他一名角色，双方各摸3张牌。',
      onUse: function (ctx) {
        const ally = ctx.targets[0];
        ctx.drawCards(ally, 3);
        ctx.drawCards(ctx.owner, 3);
      }
    },
    'qiang-lin-dan-yu': {
      id: 'qiang-lin-dan-yu', displayName: '枪林弹雨', type: 'tactical', cost: 1400, source: 'armored-transport',
      effect: '指定所有敌方造成 1+攻击+魔力 复合伤害，可打出闪抵消。',
      onUse: function (ctx) {
        const dmg = 1 + ctx.owner.getStat('attack') + ctx.owner.getStat('magic');
        ctx.getEnemies().forEach(function (e) {
          ctx.applyDamage(e, dmg, { canFlash: true });
        });
      }
    }
  };

  window.RuinedSandCityCards = cards;
})();
