// 梅尔卡坦克 - 坦克炮弹
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const SKILL = 'tank-shell';
  const FLAG = 'shellMark';
  const D = window.RuinsCommon;

  window.MelkarTankSkills = {
    id: 'melkar-tank',
    displayName: '梅尔卡坦克',
    baseStats: { attack: 16, magic: 12, speed: 12, hp: 85, maxRage: 1, maxHand: 4, drawPerTurn: 5, initDraw: 6 },

    // ⚔️ 坦克炮弹：出牌阶段限一次
    // 弃置2张单体杀牌获得一枚炮弹标记；下一回合准备阶段消耗标记
    // 指定所有敌人造成攻击力2倍伤害，每名角色需打出2张闪才能抵消
    onPlayPhase: function (context) {
      if (context.hasUsedSkill(this.id, SKILL)) return;
      if (context.hasFlag(this.id, FLAG)) return;
      const kills = context.getHandCards(context.self, { type: 'kill', single: true });
      if (kills.length < 2) return;

      const chosen = context.selectHandCards(context.self, 2, { type: 'kill', single: true });
      if (!chosen || chosen.length < 2) return;
      context.discardCards(context.self, chosen);
      context.setFlag(this.id, FLAG, true);
      context.markSkillUsed(this.id, SKILL);
      context.log('梅尔卡坦克 装填了炮弹');
    },

    // 准备阶段自动发射
    onPreparePhase: function (context) {
      if (!context.hasFlag(this.id, FLAG)) return;
      context.clearFlag(this.id, FLAG);
      const dmg = context.self.getStat('attack') * 2;
      const enemies = context.getEnemies();
      for (const e of enemies) {
        // 每名角色需打出2张闪抵消
        context.applyDamage(e, dmg, { requireFlash: 2 });
      }
      context.log('坦克炮弹发射！全体敌人受到 ' + dmg + ' 点伤害（需2张闪抵消）');
    }
  };
})();
