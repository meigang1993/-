// 废墟沙城 - 共享工具与状态牌定义
(function () {
  'use strict';

  window.__RUINS_COMMON_LOADED = true;

  const Suit = { SPADE: 'spade', HEART: 'heart', DIAMOND: 'diamond', CLUB: 'club' };
  const suitName = {
    spade: '♠黑桃', heart: '♥红桃', diamond: '♦方块', club: '♣梅花',
    black: '黑色', red: '红色'
  };

  // 状态牌类型
  const StatusType = {
    MINE: 'mine',         // 地雷（贵族军士兵）
    PARALYSIS: 'paralysis', // 麻痹（攻击型无人机）
    CONFUSION: 'confusion', // 混乱（XX型凋零者1312号）
    FREEZE: 'freeze'        // 冰冻（希尔德·冰冻术）
  };

  //  seededRng：固定种子随机，保证测试可复现（默认种子沿用项目规范）
  function seededRng(seed) {
    let s = (seed >>> 0) || 2971485;
    return {
      next: function () {
        s = (s * 1103515245 + 12345) & 0x7fffffff;
        return s / 0x7fffffff;
      },
      int: function (min, max) {
        return min + Math.floor(this.next() * (max - min + 1));
      },
      pick: function (arr) {
        return arr[this.int(0, arr.length - 1)];
      }
    };
  }

  // 生成状态牌并放入目标角色手牌区
  function addStatusCard(target, type, source) {
    const card = {
      id: 'status-' + type + '-' + Date.now() + '-' + Math.floor(Math.random() * 999),
      type: 'status',
      statusType: type,
      sourceId: source ? source.id : null,
      suit: null, // 状态牌无花色
      virtual: false
    };
    if (target && typeof target.addCard === 'function') {
      target.addCard(card);
    }
    return card;
  }

  // 判定阶段：对目标执行状态牌判定，返回 { consumed, damage, skipPlay }
  function resolveStatusCards(target, phase) {
    if (!target || !target.hand) return { consumed: [], damage: 0, skipPlay: false };
    const results = { consumed: [], damage: 0, skipPlay: false };
    const remaining = [];
    for (const card of target.hand) {
      if (card.type !== 'status' || !card.statusType) { remaining.push(card); continue; }
      const r = _resolveOne(card, target, phase);
      results.consumed.push(card);
      if (r.damage) results.damage += r.damage;
      if (r.skipPlay) results.skipPlay = true;
    }
    // 替换手牌（移除已消耗的状态牌）
    if (typeof target.setHand === 'function') target.setHand(remaining);
    else target.hand = remaining;
    return results;
  }

  // 单张状态牌判定逻辑（对照设计文档）
  function _resolveOne(card, target, phase) {
    const out = { damage: 0, skipPlay: false };
    const judge = (target.judgeCard && target.judgeCard()) || _autoJudge();
    const suit = judge.suit;

    switch (card.statusType) {
      case StatusType.MINE: { // 地雷：使用/打出响应牌时由外部触发伤害，此处仅提供判定（扫雷小游戏接口）
        // 地雷状态牌没有虚无属性；伤害 = 来源攻击力，由 onPlayResponse 处理
        break;
      }
      case StatusType.PARALYSIS: { // 麻痹：判定♥或♠ → 本回合无法使用牌
        if (suit === Suit.HEART || suit === Suit.SPADE) out.skipPlay = true;
        break;
      }
      case StatusType.CONFUSION: { // 混乱：判定♠或♥ → 随机对己方其他角色视为使用虚拟杀(普攻)
        if (suit === Suit.SPADE || suit === Suit.HEART) {
          out.forceAttack = true; // 由 BattleSystem 处理"随机攻击己方其他角色"
        }
        break;
      }
      case StatusType.FREEZE: { // 冰冻：判定♦或♣ → 本回合无法使用杀
        if (suit === Suit.DIAMOND || suit === Suit.CLUB) out.cannotKill = true;
        break;
      }
    }
    return out;
  }

  function _autoJudge() {
    const suits = [Suit.SPADE, Suit.HEART, Suit.DIAMOND, Suit.CLUB];
    return { suit: suits[Math.floor(Math.random() * 4)] };
  }

  // 通用：造成伤害
  function dealDamage(source, target, amount, opts) {
    opts = opts || {};
    if (target && typeof target.takeDamage === 'function') {
      return target.takeDamage({ amount: amount, source: source, attr: opts.attr, ignoreArmor: opts.ignoreArmor });
    }
    return amount;
  }

  // 生成虚拟杀(普攻)
  function virtualKill(source) {
    return { type: 'kill', id: 'virtual-kill-' + Date.now(), virtual: true, sourceId: source.id };
  }

  window.RuinsCommon = {
    Suit: Suit,
    suitName: suitName,
    StatusType: StatusType,
    seededRng: seededRng,
    addStatusCard: addStatusCard,
    resolveStatusCards: resolveStatusCards,
    dealDamage: dealDamage,
    virtualKill: virtualKill
  };
})();
