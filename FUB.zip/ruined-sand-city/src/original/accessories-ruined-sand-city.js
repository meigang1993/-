// 废墟沙城 - 掉落饰品（首次击败后随机掉落，图标显示在手牌区左侧）
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const D = window.RuinsCommon;

  // 每个饰品：{ id, displayName, type, source, background, onXxx }
  // 触发时机由 BattleSystem 通过 owner 身上的标记回调
  const accessories = {

    // === 普通怪物 掉落 ===
    'tui-jin-qi': {
      id: 'tui-jin-qi', displayName: '推进器', type: 'passive',
      source: ['fae-soldier', 'noble-sniper'],
      background: '世界贵族为了占领这个国家，出动了几十万军队，反抗军奋力抵抗。',
      // 根据你使用牌指定的目标数，摸等量牌
      onCardUsed: function (ctx) {
        const n = ctx.targetCount || 0;
        if (n > 0) ctx.drawCards(ctx.owner, n);
      }
    },

    // === 机械AI龙 掉落 ===
    'zhi-neng-da-nao': {
      id: 'zhi-neng-da-nao', displayName: '智能大脑', type: 'passive',
      source: ['mech-ai-dragon'],
      background: '机械龙是天界国提供的杀人AI，见活物就袭击，会造成大量平民伤亡。',
      // 战术牌造成的伤害翻倍
      onTacticalDamage: function (ctx) {
        ctx.multiplyDamage(2);
      }
    },

    // === XX型凋零者1312号 掉落 ===
    'mei-mo-gang-cha': {
      id: 'mei-mo-gang-cha', displayName: '魅魔钢叉', type: 'active',
      source: ['wither-unit-1312'],
      background: '1312号是魅魔型凋零者，没有头，身上有很多眼睛，看到她的任何生命都会发狂。',
      // 出牌阶段限一次，将♥牌当做魅杀使用，不消耗杀意
      onPlayPhase: function (ctx) {
        if (ctx.hasUsedSkill('mei-mo-gang-cha')) return;
        const heart = ctx.getCardsBySuit(ctx.owner, D.Suit.HEART)[0];
        if (!heart) return;
        ctx.useAsKill(heart, { name: '魅杀', freeRage: true });
        ctx.markSkillUsed('mei-mo-gang-cha');
      }
    },
    'fen-se-mei-mo-zhuang': {
      id: 'fen-se-mei-mo-zhuang', displayName: '粉色魅魔装', type: 'passive',
      source: ['wither-unit-1312'],
      background: '1312号有着淫神莉莉丝血脉，混沌女神与自己女儿莉莉丝交合所生。',
      // 红色牌对你无效，你使用的红色牌不可响应
      isRedCardIneffective: function (ctx) { return true; },
      isRedCardUnresponseable: function (ctx) { return true; }
    },

    // === 内英组杀手希尔德 掉落 ===
    'bing-xin-shuang-ci-jian': {
      id: 'bing-xin-shuang-ci-jian', displayName: '冰心双刺剑', type: 'passive',
      source: ['assassin-hilde'],
      background: '希尔德是伊迪斯从富豪别墅救出来的精灵少女，少女爱上了同为女性的伊迪斯。',
      // 获得的单体杀转换为刺杀，不消耗杀意
      onCardAcquired: function (ctx, card) {
        if (card.type === 'kill' && card.single) { card.converted = 'assassinate'; ctx.markFreeRage(card); }
      }
    },
    'ci-ke-jiao-yi': {
      id: 'ci-ke-jiao-yi', displayName: '刺客胶衣', type: 'active',
      source: ['assassin-hilde'],
      background: '伊迪斯被安洁莉卡打败羞辱，希尔德被NTR，为打败安洁莉卡不断训练。',
      // 出牌阶段限一次，将黑色牌当做刺杀使用，不消耗杀意
      onPlayPhase: function (ctx) {
        if (ctx.hasUsedSkill('ci-ke-jiao-yi')) return;
        const black = ctx.getBlackCards(ctx.owner)[0];
        if (!black) return;
        ctx.useAsKill(black, { name: '刺杀', freeRage: true });
        ctx.markSkillUsed('ci-ke-jiao-yi');
      }
    },

    // === 武装直升机 掉落 ===
    'luo-xuan-jiang': {
      id: 'luo-xuan-jiang', displayName: '螺旋桨', type: 'trigger',
      source: ['attack-helicopter'],
      background: '贵族军为消灭魔族雇佣兵，派出多架武装直升机。',
      // 获得任意牌时，根据摸牌数随机对敌方一名角色视为使用等量张杀(普攻)
      onCardsDrawn: function (ctx) {
        const n = ctx.drawnCount || 0;
        for (let i = 0; i < n; i++) {
          const e = ctx.randomEnemy();
          if (e) ctx.dealDamage(ctx.owner, e, ctx.owner.getStat('attack'), { virtual: true });
        }
      }
    },
    'dao-dan-fa-she-qi': {
      id: 'dao-dan-fa-she-qi', displayName: '导弹发射器', type: 'passive',
      source: ['attack-helicopter'],
      background: '贵族军以对付反抗军为由，使用不人道武器杀害大量平民。',
      // 杀指定目标时，目标需额外弃置1张杀才能响应闪
      onKillTargeting: function (ctx) {
        ctx.requireExtraFlash(1);
      }
    },

    // === 装甲运输车 掉落 ===
    'wu-zi-huo-wu': {
      id: 'wu-zi-huo-wu', displayName: '物资货物', type: 'passive',
      source: ['armored-transport'],
      background: '贵族军做好长期作战准备，无论如何都要占领这个国家。',
      // 摸牌阶段，其他角色根据你摸牌数摸等量牌
      onDrawPhase: function (ctx) {
        const n = ctx.ownerDrawCount || 0;
        ctx.getAllies().forEach(function (a) { ctx.drawCards(a, n); });
      }
    },
    'wu-qi-ku': {
      id: 'wu-qi-ku', displayName: '武器库', type: 'active',
      source: ['armored-transport'],
      background: '贵族军武器补给车。',
      // 出牌阶段限一次，让我方所有其他角色从摸牌堆摸1张杀，不消耗杀意
      onPlayPhase: function (ctx) {
        if (ctx.hasUsedSkill('wu-qi-ku')) return;
        ctx.getAllies().forEach(function (a) { ctx.drawCardOfType(a, 'kill'); });
        ctx.markSkillUsed('wu-qi-ku');
      }
    }
  };

  window.RuinedSandCityAccessories = accessories;
})();
