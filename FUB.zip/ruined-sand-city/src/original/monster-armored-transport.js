// 装甲运输车（精英）- 无脑冲撞 / 坚硬装甲 / 增援部队
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const D = window.RuinsCommon;

  window.ArmoredTransportSkills = {
    id: 'armored-transport',
    displayName: '装甲运输车',
    baseStats: { attack: 10, magic: 6, speed: 14, hp: 220, maxRage: 1, maxHand: 4, drawPerTurn: 4, initDraw: 5 },

    // ⭐ 无脑冲撞（锁定技）：获得的杀牌转换为撞杀牌，转换后自动使用，随机指定敌方一名角色
    onCardAcquired: function (context, card) {
      if (card.type !== 'kill') return;
      card.converted = 'crash-kill';
      context.autoUseCard(context.self, card, { randomEnemy: true });
      context.log('无脑冲撞：撞杀自动释放！');
    },

    // ⭐ 坚硬装甲（锁定技）：不会受到任何伤害
    isDamageImmune: function (context) {
      return true;
    },

    // 🔵 增援部队：准备阶段，当其他角色死亡后，复活已死亡的所有其他角色；每复活一名损失10%生命值直到自身死亡
    onPreparePhase: function (context) {
      const dead = context.getDeadAllies(this.id);
      if (!dead.length) return;
      for (const ally of dead) {
        context.revive(ally);
        const loss = Math.floor(context.self.getStat('hp') * 0.1);
        context.self.loseHp(loss);
      }
      context.log('增援部队：复活了 ' + dead.length + ' 名角色');
    },

    // AI：优先使用杀牌触发无脑冲撞，准备阶段自动增援
    onAIAction: function (context) {
      context.tryUseKill({ single: false });
    }
  };
})();
