// 贵族军士兵 - 放置地雷
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const SKILL = 'place-mine';
  const D = window.RuinsCommon;

  window.FaeSoldierSkills = {
    id: 'fae-soldier',
    displayName: '贵族军士兵',
    gender: 'male',
    baseStats: { attack: 11, magic: 8, speed: 12, hp: 64, maxRage: 1, maxHand: 4, drawPerTurn: 4, initDraw: 6 },

    // ⚔️ 放置地雷：出牌阶段限一次
    // 指定敌方一名角色，选一张手牌转换为地雷状态牌放入其手牌区
    // 拥有地雷的角色在使用/打出响应牌时受等同于士兵攻击力的伤害，随后地雷消耗
    // 该角色也可主动扫雷小游戏：成功则消耗、失败则受伤并消耗
    onPlayPhase: function (context) {
      if (context.hasUsedSkill(this.id, SKILL)) return;
      const enemies = context.getEnemies();
      if (!enemies.length) return;

      // AI：目标选择手牌中响应牌最多的敌方角色
      const target = enemies.reduce(function (max, e) {
        const rc = context.countResponseCards(e);
        return rc > max.rc ? { char: e, rc: rc } : max;
      }, { char: null, rc: -1 }).char;
      if (!target) return;

      const mineCard = context.selectHandCard(context.self, { filter: function () { return true; } });
      if (!mineCard) return;

      // 将该手牌转换为地雷状态牌
      const mine = D.addStatusCard(target, D.StatusType.MINE, context.self);
      mine.sourceAttack = context.self.getStat('attack');
      context.removeCard(context.self, mineCard);
      context.markSkillUsed(this.id, SKILL);
      context.log('贵族军士兵 放置了地雷');
    },

    // 响应牌触发：若使用者手牌含地雷，则受伤（在 BattleSystem 的 onPlayResponse 中调用此钩子）
    onResponseUsed: function (context, player) {
      const hand = player.hand || [];
      const idx = hand.findIndex(function (c) { return c.type === 'status' && c.statusType === D.StatusType.MINE; });
      if (idx < 0) return;
      const mine = hand[idx];
      const dmg = mine.sourceAttack || context.self.getStat('attack');
      D.dealDamage(context.self, player, dmg);
      hand.splice(idx, 1);
      context.log('地雷爆炸，' + player.displayName + ' 受到 ' + dmg + ' 点伤害');
    }
  };
})();
