// 废墟沙城 - 副本配置
(function () {
  'use strict';

  if (!window.RuinsCommon) {
    console.error('[RuinedSandCity] ruins-common.js 必须最先加载！');
  }

  const D = window.RuinsCommon;

  // 节点随机，共15层。第1层起点，第15层BOSS，
  // 篝火固定在第4层和第9层，宝箱固定在第7层。
  window.RuinedSandCity = {
    id: 'ruined-sand-city',
    displayName: '废墟沙城',
    maxLevel: 20,
    totalFloors: 15,
    startFloor: 1,
    bossFloor: 15,
    bonfireFloors: [4, 9],
    chestFloor: 7,

    // 首次通关兽人地下城勇士级后触发
    unlockCondition: {
      type: 'dungeon-clear',
      dungeonId: 'orc-dungeon',
      difficulty: 'warrior'
    },

    story: {
      unlock: '贝丝妲：罗卡尔，有件事交给你和姐姐们去做……（帮助反抗军击退世界贵族军）'
    },

    // 普通战斗节点随机抽取1至4个普通怪物，可重复（ABCD编号区分）
    normalMonsterCountRange: [1, 4],
    monsterPool: {
      normal: ['fae-soldier', 'noble-sniper', 'melkar-tank', 'attack-drone']
    },

    // 精英固定组合
    eliteCombinations: [
      ['melkar-tank', 'attack-helicopter'],
      ['melkar-tank', 'armored-transport', 'fae-soldier', 'fae-soldier'],
      ['assassin-hilde']
    ],

    // BOSS固定组合
    bossCombinations: [
      ['mech-ai-dragon', 'fae-soldier', 'noble-sniper'],
      ['wither-unit-1312', 'fae-soldier', 'attack-drone']
    ],

    cardDrops: {
      'mech-ai-dragon': ['pin-sha', 'mo-zhi-lian-sha'],
      'wither-unit-1312': ['mei-huo-shu', 'mei-sha'],
      'assassin-hilde': ['tou-xi', 'bing-dong-shu'],
      'attack-helicopter': ['liu-xing-sha', 'xi-mo-sha'],
      'armored-transport': ['wu-zi-si-fen', 'qiang-lin-dan-yu']
    },

    accessoryDrops: {
      normal: ['tui-jin-qi'],
      'mech-ai-dragon': ['zhi-neng-da-nao'],
      'wither-unit-1312': ['mei-mo-gang-cha', 'fen-se-mei-mo-zhuang'],
      'assassin-hilde': ['bing-xin-shuang-ci-jian', 'ci-ke-jiao-yi'],
      'attack-helicopter': ['luo-xuan-jiang', 'dao-dan-fa-she-qi'],
      'armored-transport': ['wu-zi-huo-wu', 'wu-qi-ku']
    },

    // 取当前层应出现的怪物列表（供 BattleSystem 调用）
    getMonstersForFloor: function (floor, rng) {
      rng = rng || D.seededRng(2971485);
      if (floor === this.bossFloor) {
        return this.bossCombinations[rng.int(0, this.bossCombinations.length - 1)];
      }
      // 精英层：在第5、10、12层左右出现固定组合，其余为普通
      const eliteFloors = [5, 10, 12];
      if (eliteFloors.indexOf(floor) >= 0) {
        return this.eliteCombinations[rng.int(0, this.eliteCombinations.length - 1)];
      }
      const count = rng.int(this.normalMonsterCountRange[0], this.normalMonsterCountRange[1]);
      const pool = this.monsterPool.normal;
      const result = [];
      for (let i = 0; i < count; i++) {
        result.push(pool[rng.int(0, pool.length - 1)]);
      }
      return result;
    }
  };
})();
