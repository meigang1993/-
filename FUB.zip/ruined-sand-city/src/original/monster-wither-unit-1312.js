// XX型凋零者1312号（领主）- 外神之眼 / 魅魔吸精术 / 百眼魅魔
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const D = window.RuinsCommon;

  window.WitherUnit1312Skills = {
    id: 'wither-unit-1312',
    displayName: 'XX型凋零者1312号',
    gender: 'female',
    entranceLine: '混沌之子转生者，看你往哪里跑，跟我回母亲大人身边吧！',
    baseStats: { attack: 12, magic: 11, speed: 13, hp: 367, maxRage: 2, maxHand: 3, drawPerTurn: 5, initDraw: 6 },

    // ⭐ 外神之眼（锁定技）：受到伤害后，使伤害来源手牌区生成一张混乱状态牌
    // 混乱牌判定♠或♥ → 随机对己方其他角色视为使用虚拟杀(普攻)；若无其他存活角色则自伤并跳过出牌阶段
    onDamaged: function (context, source) {
      if (!source) return;
      D.addStatusCard(source, D.StatusType.CONFUSION, context.self);
      context.log('外神之眼：我继承了母亲大人的邪眼。');
    },

    // ⭐ 魅魔吸精术（锁定技）：战术牌对男性伤害后获得其1张牌，对女性弃置其1张牌，对无性别2倍
    onTacticalDamageDealt: function (context, target, damage) {
      if (target.gender === 'male') {
        const card = context.stealRandomCard(target);
        if (card) context.addCard(context.self, card);
        context.log('魅魔吸精术：让我尝尝你的精气。');
      } else if (target.gender === 'female') {
        context.discardRandomCard(target);
        context.log('魅魔吸精术：弃置了女性的牌。');
      } else {
        D.dealDamage(context.self, target, damage.amount); // 无性别：2倍（再造成一次=共2倍）
        context.log('魅魔吸精术：对无性别造成2倍伤害。');
      }
    },

    // 🔵 百眼魅魔：结束阶段若有♥牌，弃置所有♥牌，使所有敌方随机互杀（无存活其他角色则自伤并跳过出牌阶段）
    onEndPhase: function (context) {
      const hearts = context.getCardsBySuit(context.self, D.Suit.HEART);
      if (!hearts.length) return;
      context.discardCards(context.self, hearts);
      const enemies = context.getEnemies();
      for (const e of enemies) {
        const others = enemies.filter(function (x) { return x !== e; });
        if (others.length) {
          const victim = others[Math.floor(Math.random() * others.length)];
          D.dealDamage(e, victim, e.getStat('attack'));
        } else {
          D.dealDamage(e, e, e.getStat('attack'));
          context.setSkipPlay(e);
        }
      }
      context.log('百眼魅魔：都发狂吧！');
    },

    // AI：出牌阶段优先使用战术牌对男性角色造成伤害；结束阶段若有♥则发动百眼魅魔
    onAIAction: function (context) {
      const males = context.getEnemies().filter(function (e) { return e.gender === 'male'; });
      if (males.length) context.tryUseTactical({ preferTarget: males[0] });
      else context.tryUseKill({ single: true });
      this.onEndPhase(context);
    }
  };
})();
