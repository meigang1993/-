// 内英组杀手希尔德（精英）- 暗幕隐身 / 影舞步 / 潜影背刺
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const D = window.RuinsCommon;

  window.AssassinHildeSkills = {
    id: 'assassin-hilde',
    displayName: '内英组杀手希尔德',
    gender: 'female',
    entranceLine: '是你打败了伊迪斯？哼，要不是魔后艾恩大人要活捉你，不可能输给你。我不会对你手下留情。',
    baseStats: { attack: 11, magic: 10, speed: 16, hp: 230, maxRage: 2, maxHand: 3, drawPerTurn: 4, initDraw: 5 },

    // ⭐ 暗幕隐身（锁定技）：若有黑色牌，不会成为单体杀的目标
    isInvalidSingleKillTarget: function (context) {
      return context.hasBlackCard(context.self);
    },

    // 🔵 影舞步：准备阶段连续判定，黑色则获得该判定牌，红色则停止；以此获得的黑色杀不消耗杀意
    onPreparePhase: function (context) {
      while (true) {
        const judge = context.judgeCard();
        if (judge.suit === D.Suit.HEART || judge.suit === D.Suit.DIAMOND) break; // 红色停止
        context.addCard(context.self, judge);
        if (judge.type === 'kill') context.markFreeRage(judge); // 黑色杀不耗杀意
      }
      context.log('影舞步：获得了黑色牌。');
    },

    // 🔵 潜影背刺：若有黑色牌，指定敌方一名角色造成攻击力物理伤害
    onPlayPhase: function (context) {
      if (!context.hasBlackCard(context.self)) return;
      const target = context.chooseTarget(this.id, { enemiesOnly: true, single: true });
      if (!target) return;
      const dmg = context.self.getStat('attack');
      D.dealDamage(context.self, target, dmg, { attr: 'physical' });
      context.log('潜影背刺：我就在你背后呀。');
    },

    // AI：准备阶段自动影舞步；出牌阶段优先潜影背刺再单体杀
    onAIAction: function (context) {
      this.onPreparePhase(context);
      if (context.hasBlackCard(context.self)) this.onPlayPhase(context);
      else context.tryUseKill({ single: true });
    }
  };
})();
