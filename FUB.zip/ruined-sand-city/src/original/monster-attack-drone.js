// 攻击型无人机 - 麻痹毒子弹
(function () {
  'use strict';
  if (!window.__RUINS_COMMON_LOADED) console.error('[RuinedSandCity] ruins-common.js 必须先加载');

  const D = window.RuinsCommon;

  window.AttackDroneSkills = {
    id: 'attack-drone',
    displayName: '攻击型无人机',
    baseStats: { attack: 12, magic: 10, speed: 17, hp: 47, maxRage: 2, maxHand: 3, drawPerTurn: 4, initDraw: 5 },

    // ⭐ 麻痹毒子弹（锁定技）
    // 单体杀造成毒属性伤害并施加毒标记；造成伤害后使目标生成一张麻痹状态牌
    // 麻痹牌判定♥或♠ → 本回合无法使用牌
    onKillDamageDealt: function (context, target, damage) {
      if (!context.isSingleKill(damage.card)) return;
      context.applyMark(target, 'poison', { source: this.id });
      D.addStatusCard(target, D.StatusType.PARALYSIS, context.self);
      context.log('攻击型无人机 施加了麻痹毒子弹');
    },

    // AI：优先使用单体杀，目标选生命值最低的敌方角色
    onAIAction: function (context) {
      const enemies = context.getEnemies();
      const target = enemies.reduce(function (min, e) {
        return e.getStat('hp') < (min ? min.getStat('hp') : Infinity) ? e : min;
      }, null);
      context.tryUseKill({ single: true, preferTarget: target });
    }
  };
})();
