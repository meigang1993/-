-- ==========================================
-- 废墟沙城 · 领主（BOSS）怪物
-- ==========================================

local M = {}
local attr = function(t)
    return {
        attack = t[1], magic = t[2], speed = t[3], hp = t[4],
        maxKillingIntent = t[5], maxHandSize = t[6],
        drawPerTurn = {base = t[7], bonus = t[8]},
        initialDraw  = {base = t[9], bonus = t[10]},
    }
end

-- 机械AI龙
M.mech_ai_dragon = {
    name = "机械AI龙", type = "领主", faction = "废墟沙城",
    baseAttributes = attr{13,8,15,342, 1,4, 2,2, 4,1},

    skills = {
        -- 🔵 电钻火花：【杀】造成伤害时可摇骰子，按点数增加额外攻击次数
        drillSpark = {
            type = "active",
            onSlashDamage = function(self, p, target, dmg)
                local dice = p:rollDice()
                return {extraHits = dice}  -- 额外攻击次数 = 骰子点数
            end,
        },

        -- ⭐ 机尾机枪：锁定技，敌方出牌阶段当你受攻击次数达到手牌数时，对敌方使用【机枪扫杀】，按伤害获得等量护甲
        tailGatling = {
            type = "locked",
            attackCount = 0,
            onAttacked = function(self, p, source)
                self.attackCount = self.attackCount + 1
                if self.attackCount >= p:getHandSize() then
                    self.attackCount = 0
                    local dmg = p:useCard("机枪扫杀", source)
                    p:gainArmor(dmg)  -- 获得等量护甲
                end
            end,
        },

        -- 🔵 死亡音波：结束阶段记录手中任意张牌花色；敌方回合内若未使用该花色，回合结束对其造成攻击力伤害
        deathSoundwave = {
            type = "active",
            recordedSuits = {},
            onEndPhase = function(self, p)
                local cards = p:chooseCards(p:getHandCards(), "记录任意张牌的花色")
                self.recordedSuits = {}
                for _, c in ipairs(cards) do
                    self.recordedSuits[c:getSuit()] = true
                end
            end,
            -- 敌方回合结束时检查其是否使用过记录的花色
            onEnemyTurnEnd = function(self, p, enemy)
                local usedSuits = enemy:getSuitsUsedThisTurn()
                local missing = false
                for suit, _ in pairs(self.recordedSuits) do
                    if not usedSuits[suit] then missing = true; break end
                end
                if missing then
                    p:dealDamage(enemy, p:getAttack())
                end
            end,
        },
    },

    ai = {
        onPlay = function(self, p)
            p:useSingleSlash()  -- 优先使用单体杀
        end,
        onEndPhase = function(self, p)
            -- 自动记录手中数量最多的花色
            local best = p:getMostCountSuit()
            self.skills.deathSoundwave.recordedSuits = {[best] = true}
        end,
    },
}

-- XX型凋零者1312号
M.damned_1312 = {
    name = "XX型凋零者1312号", type = "领主", gender = "女", faction = "废墟沙城",
    baseAttributes = attr{12,11,13,367, 2,3, 2,3, 4,2},
    entranceLine = "混沌之子转生者，看你往哪里跑，跟我回母亲大人身边吧！",

    skills = {
        -- ⭐ 外神之眼：受伤后使伤害来源手牌区生成混乱状态牌；判定♠/♥则该角色随机对我方另一名角色视为用虚拟【杀(普攻)】，若无存活他人则自伤攻击力并跳过出牌阶段
        outerGodsEye = {
            type = "locked",
            onDamaged = function(self, p, source)
                source:addStateCard("confusion")
            end,
            onJudge = function(self, p, stateCard)
                if stateCard:isState("confusion") then
                    local suit = stateCard:getSuit()
                    if suit == "spade" or suit == "heart" then
                        local allies = p:getAliveAllies()
                        local others = p:getOtherAliveAllies()
                        if #others > 0 then
                            local tgt = others[math.random(#others)]
                            p:createVirtualSlash(tgt, {base = "普攻"})
                        else
                            -- 没有其他存活角色：对自己造成攻击力伤害
                            p:dealDamage(p, p:getAttack())
                            p:setFlag("skip_play_phase", true)
                        end
                    end
                end
            end,
        },

        -- ⭐ 魅魔吸精术：战术牌对男性造成伤害后获得其1张牌，对女性弃置其1张牌，对无性别伤害2倍
        succubusDrain = {
            type = "locked",
            onTacticDamage = function(self, p, target, dmg)
                local g = target:getGender()
                if g == "男" then
                    p:obtainCard(target:giveRandomCard())
                    p:speak("让我尝尝你的精气。")
                elseif g == "女" then
                    target:discardRandomCard()
                    p:speak("让我尝尝你的精气。")
                elseif g == "无" then
                    return {damageMultiplier = 2}
                end
            end,
        },

        -- 🔵 百眼魅魔：结束阶段若有♥红桃牌，弃置所有♥，使所有敌方角色随机对我方另一名角色视为用虚拟【杀(普攻)】；无他人则自伤
        hundredEyes = {
            type = "active",
            onEndPhase = function(self, p)
                local hearts = p:getCardsBySuit("heart")
                if #hearts == 0 then return end
                p:discardCards(hearts)
                local enemies = p:getEnemies()
                for _, e in ipairs(enemies) do
                    local others = e:getOtherAliveAllies()
                    if #others > 0 then
                        local tgt = others[math.random(#others)]
                        e:createVirtualSlash(tgt, {base = "普攻"})
                    else
                        e:dealDamage(e, e:getAttack())
                    end
                end
                p:speak("都发狂吧！")
            end,
        },
    },

    ai = {
        onPlay = function(self, p)
            -- 优先使用战术牌对男性角色造成伤害
            local tactic = p:chooseTacticAgainstMale()
            if tactic then tactic:use()
            else p:useAnySlash() end
        end,
        onEndPhase = function(self, p)
            if #p:getCardsBySuit("heart") > 0 then
                self.skills.hundredEyes:onEndPhase(p)
            end
        end,
    },
}

return M
