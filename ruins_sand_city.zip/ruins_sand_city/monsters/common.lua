-- ==========================================
-- 废墟沙城 · 普通怪物
-- ==========================================

local M = {}

-- 通用属性构造
local function attr(t)
    return {
        attack = t[1], magic = t[2], speed = t[3], hp = t[4],
        maxKillingIntent = t[5], maxHandSize = t[6],
        drawPerTurn = {base = t[7], bonus = t[8]},
        initialDraw  = {base = t[9], bonus = t[10]},
    }
end

-- 贵族军士兵
M.noble_soldier = {
    name = "贵族军士兵", type = "普通", gender = "男", faction = "废墟沙城",
    baseAttributes = attr{11,8,12,64, 1,4, 2,2, 4,2},

    skills = {
        -- ⚔️ 放置地雷
        placeMine = {
            type = "active", phase = "play", limit = "once_per_phase",
            canUse = function(self, p) return not p:hasFlag("mine_used") end,
            onUse = function(self, p)
                local enemies = p:getEnemies()
                -- 目标：手牌中响应牌最多的敌方角色
                local target = p:chooseTargetByMaxRespondCards(enemies)
                if not target then return end
                local card = p:chooseCard(p:getHandCards(), 1, "选择一张手牌转换为地雷")
                if not card then return end
                -- 将该牌转换为地雷状态牌，放入目标手牌区
                local mine = card:convertToMineState()
                target:addToHand(mine)
                p:setFlag("mine_used", true)
            end,
        },
    },

    ai = {
        onPlay = function(self, p)
            -- 优先放置地雷
            if self.skills.placeMine:canUse(p) then
                self.skills.placeMine:onUse(p)
            end
        end,
    },
}

-- 贵族军狙击手
M.noble_sniper = {
    name = "贵族军狙击手", type = "普通", gender = "男", faction = "废墟沙城",
    baseAttributes = attr{14,9,15,58, 1,4, 2,1, 4,1},

    skills = {
        -- ⚔️ 狙击目标（与亚缇娜同款机制）
        snipeTarget = {
            type = "active", phase = "play", limit = "once_per_phase",
            canUse = function(self, p) return not p:hasFlag("sniper_used") end,
            onUse = function(self, p)
                local enemies = p:getEnemies()
                local target = p:chooseTarget(enemies, "选择狙击目标")
                if not target then return end
                local shown = target:showRandomHandCard()
                if shown then
                    local suit = shown:getSuit()
                    if p:countHandCardsBySuit(suit) > target:countHandCardsBySuit(suit) then
                        p:setFlag("snipe_target", target)
                        p:setFlag("snipe_target_suit", suit)
                    end
                    p:setFlag("sniper_used", true)
                end
            end,
            onModifySlash = function(self, p, slash, target)
                local t = p:getFlag("snipe_target")
                if t and t == target then return {cannotRespond = true} end
                return nil
            end,
        },
    },

    ai = {
        onPlay = function(self, p)
            -- 优先蓄力+单体杀 或直接单体杀
            if self.skills.snipeTarget:canUse(p) then
                self.skills.snipeTarget:onUse(p)
            end
            p:useSingleSlash()
        end,
    },
}

-- 梅尔卡坦克
M.merka_tank = {
    name = "梅尔卡坦克", type = "普通", faction = "废墟沙城",
    baseAttributes = attr{16,12,12,85, 1,4, 2,3, 4,2},

    skills = {
        -- ⚔️ 坦克炮弹
        tankShell = {
            type = "active", phase = "play", limit = "once_per_phase",
            canUse = function(self, p) return not p:hasFlag("shell_used") end,
            onUse = function(self, p)
                local slashes = p:getHandCardsByType("slash_single")
                if #slashes < 2 then return end
                local cards = p:chooseCards(slashes, 2, "弃置2张单体【杀】获得炮弹标记")
                if #cards ~= 2 then return end
                p:discardCards(cards)
                p:addMark("cannon_shell")   -- 炮弹标记
                p:setFlag("shell_used", true)
            end,
            -- 下一个回合准备阶段发射
            onPrepare = function(self, p)
                if p:hasMark("cannon_shell") then
                    p:consumeMark("cannon_shell")
                    local enemies = p:getEnemies()
                    -- 攻击力2倍伤害，每名角色需打出2张【闪】抵消
                    for _, e in ipairs(enemies) do
                        p:dealDamage(e, p:getAttack() * 2, {
                            dodgeNeed = 2, dodgeCard = "闪",
                        })
                    end
                end
            end,
        },
    },

    ai = {
        onPlay = function(self, p)
            -- 优先弃置单体杀获得炮弹标记
            if self.skills.tankShell:canUse(p) then
                self.skills.tankShell:onUse(p)
            end
        end,
    },
}

-- 攻击型无人机
M.attack_drone = {
    name = "攻击型无人机", type = "普通", faction = "废墟沙城",
    baseAttributes = attr{12,10,17,47, 2,3, 2,2, 4,1},

    skills = {
        -- ⭐ 麻痹毒子弹
        paralyzePoison = {
            type = "locked",
            onDamageDealt = function(self, p, source, target, dmg, card)
                if not card or not card:isSingleSlash() then return end
                -- 毒属性伤害 + 毒标记
                target:addMark("poison")
                -- 造成伤害后生成麻痹状态牌
                target:addStateCard("paralyze")
            end,
            -- 麻痹状态牌判定：♥或♠ -> 本回合无法使用牌
            onJudge = function(self, p, stateCard)
                if stateCard:isState("paralyze") then
                    local suit = stateCard:getSuit()
                    if suit == "heart" or suit == "spade" then
                        p:setFlag("cannot_use_card", true)
                    end
                end
            end,
        },
    },

    ai = {
        onPlay = function(self, p)
            -- 优先单体杀，目标选生命值最低
            p:useSingleSlashTargetLowestHP()
        end,
    },
}

return M
