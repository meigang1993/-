-- ==========================================
-- 废墟沙城 · 精英怪物
-- ==========================================

local M = {}
local attr = function(t)
    return {
        attack = t[1], magic = t[2], speed = t[3], hp = t[4],
        maxKillingIntent = t[5], maxHandSize = t[6],
        drawPerTurn = {base = t[7], bonus = t[8]},
        initialDraw  = {base = t[9], bonus = t[10]},
    }
end

-- 内英组杀手希尔德
M.hilde = {
    name = "内英组杀手希尔德", type = "精英", gender = "女", faction = "废墟沙城",
    baseAttributes = attr{11,10,16,230, 2,3, 2,2, 4,1},
    entranceLine = "是你打败了伊迪斯？哼，要不是魔后艾恩大人要活捉你，不可能输给你。我不会对你手下留情。",

    skills = {
        -- ⭐ 暗幕隐身：有黑色牌 -> 不会成为单体【杀】目标
        darkCloak = {
            type = "locked",
            onTargetFilter = function(self, p, source, card)
                if card and card:isSingleSlash() and p:hasBlackCard() then
                    return {invalid = true}
                end
                return nil
            end,
        },

        -- 🔵 影舞步：准备阶段连续判定，黑色=获得并继续，红色=停止；黑色【杀】不耗杀意
        shadowDance = {
            type = "active",
            onPrepare = function(self, p)
                while true do
                    local judge = p:doJudge()
                    if judge:isBlack() then
                        p:obtainCard(judge)           -- 获得该黑色判定牌
                        if judge:isSlash() then
                            judge:setNoIntentCost(true)
                        end
                    else
                        break  -- 红色停止
                    end
                end
            end,
        },

        -- 🔵 潜影背刺：有黑色牌 -> 指定1名敌人造成攻击力物理伤害
        sneakBackstab = {
            type = "active", phase = "play",
            canUse = function(self, p) return p:hasBlackCard() end,
            onUse = function(self, p)
                local target = p:chooseTarget(p:getEnemies(), "潜影背刺目标")
                if target then
                    p:dealDamage(target, p:getAttack(), {element = "physical"})
                    p:speak("我就在你背后呀。")
                end
            end,
        },
    },

    ai = {
        onPrepare = function(self, p)
            self.skills.shadowDance:onPrepare(p)   -- 自动影舞步
        end,
        onPlay = function(self, p)
            if self.skills.sneakBackstab:canUse(p) then
                self.skills.sneakBackstab:onUse(p)  -- 优先潜影背刺
            end
            p:useSingleSlash()
        end,
    },
}

-- 武装直升机
M.gunship = {
    name = "武装直升机", type = "精英", faction = "废墟沙城",
    baseAttributes = attr{9,8,12,210, 1,5, 2,3, 4,2},

    skills = {
        -- ⚔️ 战场扫射：2张同花色牌当【机枪扫杀】用，不耗杀意
        battlefieldSweep = {
            type = "active", phase = "play",
            canUse = function(self, p) return p:hasSameSuitPair() end,
            onUse = function(self, p)
                local cards = p:chooseSameSuitPair()
                if cards then
                    p:discardCards(cards)
                    p:useCardAs("机枪扫杀", {noIntentCost = true})
                end
            end,
        },

        -- ⭐ 继续压制：【杀】被【闪】抵消时摸1张
        keepPressing = {
            type = "locked",
            onSlashDodged = function(self, p, target)
                p:drawCards(1)
            end,
        },
    },

    ai = {
        onPlay = function(self, p)
            if self.skills.battlefieldSweep:canUse(p) then
                self.skills.battlefieldSweep:onUse(p)  -- 优先战场扫射
            else
                p:useAnySlash()
            end
        end,
    },
}

-- 装甲运输车
M.armored_truck = {
    name = "装甲运输车", type = "精英", faction = "废墟沙城",
    baseAttributes = attr{10,6,14,220, 1,4, 2,2, 4,1},

    skills = {
        -- ⭐ 无脑冲撞：【杀】牌转换为【撞杀】并自动使用，随机指定敌人
        recklessRam = {
            type = "locked",
            onObtainSlash = function(self, p, card)
                local slam = card:convertTo("撞杀")
                return slam  -- 转换后交给使用流程
            end,
            onUseSlash = function(self, p, slash)
                if slash:is("撞杀") then
                    slash:autoTargetRandom()
                end
            end,
        },

        -- ⭐ 坚硬装甲：不会受到任何伤害
        hardArmor = {
            type = "locked",
            onDamageTaken = function(self, p, dmg, source)
                return 0  -- 免疫一切伤害
            end,
        },

        -- 🔵 增援部队：准备阶段，其他角色死亡后复活所有已死亡其他角色，每复活1名自身损失10%生命，直到自身死亡
        reinforcements = {
            type = "active",
            onPrepare = function(self, p)
                if p:hasDeadOthers() then
                    local revived = p:reviveAllDeadOthers()
                    for _ = 1, revived do
                        p:losePercentHP(10)
                    end
                end
            end,
        },
    },

    ai = {
        onPrepare = function(self, p)
            self.skills.reinforcements:onPrepare(p)
        end,
        onPlay = function(self, p)
            p:useAnySlash()  -- 优先使用杀牌触发无脑冲撞
        end,
    },
}

return M
