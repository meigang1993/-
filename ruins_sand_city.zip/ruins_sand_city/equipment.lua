-- ==========================================
-- 废墟沙城 · 饰品掉落（首次击败随机掉落）
-- 饰品技能图标显示在手牌区左侧
-- ==========================================

local M = {}
M.equipment = {}

-- 推进器（普通怪物掉落：士兵/狙击手）
M.equipment.booster = {
    id = "booster", name = "推进器", type = "被动",
    source = {"贵族军士兵", "贵族军狙击手"},
    desc = "根据你使用牌指定的目标数，你摸等量牌。",
    onCardUsed = function(self, p, card, targetCount)
        if targetCount and targetCount > 0 then
            p:drawCards(targetCount)
        end
    end,
}

-- 智能大脑（机械AI龙）
M.equipment.smart_brain = {
    id = "smart_brain", name = "智能大脑", type = "被动",
    source = {"机械AI龙"},
    desc = "战术牌造成的伤害翻倍。",
    onTacticDamage = function(self, p, dmg)
        return dmg * 2
    end,
}

-- 魅魔钢叉（XX型凋零者1312号）
M.equipment.succubus_pitchfork = {
    id = "succubus_pitchfork", name = "魅魔钢叉", type = "主动",
    source = {"XX型凋零者1312号"},
    desc = "出牌阶段限一次，你可以将♥红桃牌当做【魅杀】使用，若如此做不消耗杀意。",
    onUse = function(self, p)
        if p:hasFlag("pitchfork_used") then return end
        local hearts = p:getCardsBySuit("heart")
        local card = p:chooseCard(hearts, 1, "选择♥红桃牌当做【魅杀】")
        if card then
            p:useCardAs("魅杀", {card = card, noIntentCost = true})
            p:setFlag("pitchfork_used", true)
        end
    end,
}

-- 粉色魅魔装（XX型凋零者1312号）
M.equipment.pink_succubus = {
    id = "pink_succubus", name = "粉色魅魔装", type = "被动",
    source = {"XX型凋零者1312号"},
    desc = "红色牌对你无效，你使用的红色牌不可响应。",
    onDamageTaken = function(self, p, dmg, source, card)
        if card and card:isRed() then return 0 end  -- 红色牌无效
        return dmg
    end,
    onModifyOutgoing = function(self, p, card)
        if card and card:isRed() then return {unrespondable = true} end
        return nil
    end,
}

-- 冰心双刺剑（内英组杀手希尔德）
M.equipment.ice_twin_swords = {
    id = "ice_twin_swords", name = "冰心双刺剑", type = "被动",
    source = {"内英组杀手希尔德"},
    desc = "你获得的单体【杀】牌转换为【刺杀】，转换的【刺杀】牌不消耗杀意。",
    onObtainSlash = function(self, p, card)
        if card:isSingleSlash() then
            local stab = card:convertTo("刺杀")
            stab:setNoIntentCost(true)
            return stab
        end
        return card
    end,
}

-- 刺客胶衣（内英组杀手希尔德）
M.equipment.assassin_suit = {
    id = "assassin_suit", name = "刺客胶衣", type = "主动",
    source = {"内英组杀手希尔德"},
    desc = "出牌阶段限一次，你可以将黑色牌当做【刺杀】使用，不消耗杀意。",
    onUse = function(self, p)
        if p:hasFlag("assassin_suit_used") then return end
        local blacks = p:getBlackCards()
        local card = p:chooseCard(blacks, 1, "选择黑色牌当做【刺杀】")
        if card then
            p:useCardAs("刺杀", {card = card, noIntentCost = true})
            p:setFlag("assassin_suit_used", true)
        end
    end,
}

-- 螺旋桨（武装直升机）
M.equipment.propeller = {
    id = "propeller", name = "螺旋桨", type = "触发",
    source = {"武装直升机"},
    desc = "当你获得任意张牌时，你可以根据摸的牌数，随机对敌方一名角色视为使用等量张【杀(普攻)】牌。",
    onCardsDrawn = function(self, p, count)
        if count <= 0 then return end
        for i = 1, count do
            local e = p:chooseRandomEnemy()
            if e then p:createVirtualSlash(e, {base = "普攻"}) end
        end
    end,
}

-- 导弹发射器（武装直升机）
M.equipment.missile_launcher = {
    id = "missile_launcher", name = "导弹发射器", type = "被动",
    source = {"武装直升机"},
    desc = "你使用的【杀】牌指定目标时，目标角色需要额外弃置1张【杀】牌才能响应【闪】。",
    onModifyDodge = function(self, p, target)
        return {extraDiscard = {"杀", 1}}
    end,
}

-- 物资货物（装甲运输车）
M.equipment.supply_cargo = {
    id = "supply_cargo", name = "物资货物", type = "被动",
    source = {"装甲运输车"},
    desc = "摸牌阶段，你摸牌时，其他角色根据你摸的牌数摸等量的牌。",
    onDrawCards = function(self, p, count)
        for _, ally in ipairs(p:getAllies()) do
            ally:drawCards(count)
        end
    end,
}

-- 武器库（装甲运输车）
M.equipment.armory = {
    id = "armory", name = "武器库", type = "主动",
    source = {"装甲运输车"},
    desc = "出牌阶段限一次，你可以让我方所有其他角色从摸牌堆里摸1张【杀】牌，此【杀】牌不消耗杀意。",
    onUse = function(self, p)
        if p:hasFlag("armory_used") then return end
        for _, ally in ipairs(p:getAllies()) do
            local slash = p:drawSpecificFromDeck("杀")
            if slash then
                slash:setNoIntentCost(true)
                ally:obtainCard(slash)
            end
        end
        p:setFlag("armory_used", true)
    end,
}

return M
