-- ==========================================
-- 废墟沙城 · 卡牌掉落（别墅商店解锁）
-- 首次击败对应怪物后解锁
-- ==========================================

local M = {}
M.cards = {}

-- 机械AI龙 掉落
M.cards.zhuan_sha = {
    id = "zhuan_sha", name = "拼杀", type = "杀", cost = 1200,
    source = "机械AI龙",
    desc = "指定敌方角色，造成等同于你攻击力的伤害。指定敌方角色时，若你的【杀】牌数量大于目标角色，此【杀】牌不可响应。",
    onUse = function(self, p)
        local target = p:chooseTarget(p:getEnemies())
        if not target then return end
        local unrespondable = p:countCardsByType("杀") > target:countCardsByType("杀")
        p:dealDamage(target, p:getAttack(), {unrespondable = unrespondable})
    end,
}

M.cards.mo_zhi_lian_sha = {
    id = "mo_zhi_lian_sha", name = "魔之连杀", type = "杀", cost = 1400,
    source = "机械AI龙",
    desc = "指定敌方角色，造成等同于你魔力值的伤害。根据你【杀】牌数量，额外随机指定目标。",
    onUse = function(self, p)
        local target = p:chooseTarget(p:getEnemies())
        if not target then return end
        local extra = p:countCardsByType("杀")
        p:dealDamage(target, p:getMagic())
        for i = 1, extra do
            local t2 = p:chooseRandomEnemy()
            if t2 then p:dealDamage(t2, p:getMagic()) end
        end
    end,
}

-- XX型凋零者1312号 掉落
M.cards.mei_huo_shu = {
    id = "mei_huo_shu", name = "魅惑术", type = "障碍", cost = 1200,
    source = "XX型凋零者1312号",
    desc = "指定敌方一名角色，使其手牌区生成一张混乱状态牌。",
    onUse = function(self, p)
        local target = p:chooseTarget(p:getEnemies())
        if target then target:addStateCard("confusion") end
    end,
}

M.cards.mei_sha = {
    id = "mei_sha", name = "魅杀", type = "杀", cost = 1400,
    source = "XX型凋零者1312号",
    desc = "指定敌方一名角色，造成等同于你魔力值的魔法伤害，并施加脆弱标记。拥有此标记的角色受到伤害+50%。",
    onUse = function(self, p)
        local target = p:chooseTarget(p:getEnemies())
        if not target then return end
        p:dealDamage(target, p:getMagic(), {element = "magic"})
        target:addMark("fragile")  -- 脆弱：受到伤害+50%
    end,
}

-- 内英组杀手希尔德 掉落
M.cards.tou_xi = {
    id = "tou_xi", name = "偷袭", type = "响应", cost = 1100,
    source = "内英组杀手希尔德",
    desc = "当敌方角色使用战术牌后，对其造成等同于你攻击力的物理伤害。",
    onEnemyUseTactic = function(self, p, enemy)
        p:dealDamage(enemy, p:getAttack(), {element = "physical"})
    end,
}

M.cards.bing_dong_shu = {
    id = "bing_dong_shu", name = "冰冻术", type = "障碍", cost = 1500,
    source = "内英组杀手希尔德",
    desc = "指定敌方一名角色，使其手牌区生成一张冰冻状态牌。判定阶段若为♦方块或♣梅花，该角色本回合无法使用【杀】牌。",
    onUse = function(self, p)
        local target = p:chooseTarget(p:getEnemies())
        if target then target:addStateCard("freeze") end
    end,
    onJudge = function(self, p, stateCard)
        if stateCard:isState("freeze") then
            local s = stateCard:getSuit()
            if s == "diamond" or s == "club" then
                p:setFlag("cannot_use_slash", true)
            end
        end
    end,
}

-- 武装直升机 掉落
M.cards.liu_xing_sha = {
    id = "liu_xing_sha", name = "流星杀", type = "杀", cost = 1200,
    source = "武装直升机",
    desc = "使用后指定所有敌方角色，造成等同于你魔力值的魔法伤害。",
    onUse = function(self, p)
        for _, e in ipairs(p:getEnemies()) do
            p:dealDamage(e, p:getMagic(), {element = "magic"})
        end
    end,
}

M.cards.xi_mo_sha = {
    id = "xi_mo_sha", name = "吸魔杀", type = "杀", cost = 1600,
    source = "武装直升机",
    desc = "指定敌方一名角色，造成等同于你魔力值的魔法伤害，造成伤害后获得该角色1张牌。",
    onUse = function(self, p)
        local target = p:chooseTarget(p:getEnemies())
        if not target then return end
        p:dealDamage(target, p:getMagic(), {element = "magic"})
        p:obtainCard(target:giveRandomCard())
    end,
}

-- 装甲运输车 掉落
M.cards.wu_zi_si_fen = {
    id = "wu_zi_si_fen", name = "物资私分", type = "消耗", cost = 1700,
    source = "装甲运输车",
    desc = "指定我方其他一名角色，使双方各摸3张牌。",
    onUse = function(self, p)
        local ally = p:chooseTarget(p:getAllies())
        if not ally then return end
        p:drawCards(3)
        ally:drawCards(3)
    end,
}

M.cards.qiang_lin_dan_yu = {
    id = "qiang_lin_dan_yu", name = "枪林弹雨", type = "战术", cost = 1400,
    source = "装甲运输车",
    desc = "使用后指定所有敌方角色，造成基础1点+攻击力+魔力复合伤害。若有【闪】牌，敌方角色可自动打出抵消。",
    onUse = function(self, p)
        local dmg = 1 + p:getAttack() + p:getMagic()
        for _, e in ipairs(p:getEnemies()) do
            p:dealDamage(e, dmg, {canDodge = true, dodgeCard = "闪"})
        end
    end,
}

return M
