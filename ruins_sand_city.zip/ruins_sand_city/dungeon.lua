-- ==========================================
-- 废墟沙城 · 副本结构
-- 15层，节点随机，篝火/宝箱固定，怪物池与固定组合
-- ==========================================

local Common = require("ruins_sand_city.monsters.common")
local Elite  = require("ruins_sand_city.monsters.elite")
local Lord   = require("ruins_sand_city.monsters.lord")

local M = {}

M.id = "ruins_sand_city"
M.name = "废墟沙城"
M.maxLevel = 20              -- 等级上限提高至20级
M.totalFloors = 15           -- 共15层

-- 固定节点（用楼层编号做 key，便于 O(1) 查询）
M.fixed = {
    bonfire = {[4] = true, [9] = true},   -- 篝火固定在第4、9层
    chest   = {[7] = true},               -- 宝箱固定在第7层
    boss    = 15,                         -- 第15层 BOSS
    start   = 1,                          -- 第1层起点
}

-- 普通怪物池（随机抽取，可重复，以ABCD编号区分，可4个相同）
M.commonPool = {
    Common.noble_soldier,
    Common.noble_sniper,
    Common.merka_tank,
    Common.attack_drone,
}

-- 每层的普通怪物数量：随机抽取1~4个
function M:rollCommonCount()
    return math.random(1, 4)
end

-- 精英固定组合
M.eliteCombos = {
    {Common.merka_tank, Elite.gunship},                                          -- 组合一
    {Common.merka_tank, Elite.armored_truck, Common.noble_soldier, Common.noble_soldier}, -- 组合二
    {Elite.hilde},                                                               -- 组合三
}

-- BOSS固定组合
M.bossCombos = {
    {Lord.mech_ai_dragon, Common.noble_soldier, Common.noble_sniper},
    {Lord.damned_1312,    Common.noble_soldier, Common.attack_drone},
}

-- 生成某一层的战斗节点
function M:generateFloor(floor)
    if floor == self.fixed.boss then
        -- BOSS层：从固定组合中随机选一组
        local combo = self.bossCombos[math.random(#self.bossCombos)]
        return {type = "boss", enemies = combo}
    end

    -- 篝火 / 宝箱固定节点
    if self.fixed.bonfire[floor] then
        return {type = "bonfire"}
    end
    if self.fixed.chest[floor] then
        return {type = "chest"}
    end

    -- 普通战斗节点：抽1~4只普通怪（可重复，ABCD区分）
    local count = self:rollCommonCount()
    local enemies = {}
    for i = 1, count do
        local m = self.commonPool[math.random(#self.commonPool)]
        table.insert(enemies, {proto = m, tag = string.char(64 + i)})  -- A/B/C/D
    end
    return {type = "battle", enemies = enemies}
end

-- 生成完整副本
function M:generate()
    local dungeon = {id = self.id, name = self.name, floors = {}}
    for f = 1, self.totalFloors do
        dungeon.floors[f] = self:generateFloor(f)
    end
    return dungeon
end

-- ==========================================
-- 解锁事件（剧情）
-- 首次通关「兽人地下城·勇士级」后触发
-- ==========================================
M.unlockEvent = {
    precondition = "first_clear_orc_dungeon_heroic",

    script = {
        {speaker = "贝丝妲", text = "罗卡尔，有件事交给你和姐姐们去做。"},
        {speaker = "罗卡尔", text = "又要我去做什么？妈妈。"},
        {speaker = "贝丝妲", text = "你那双胞胎姐姐，还有卡迪西斯，都去加撒地区打仗去了，我很担心他们的安危。"},
        {speaker = "罗卡尔", text = "为什么要去这么危险的地方？"},
        {speaker = "贝丝妲", text = "还不是因为卡迪西斯的女人——那个女人家乡被世界贵族侵略了，我们必须帮一下。"},
        {speaker = "罗卡尔", text = "我去就行。不过妈妈，事情结束后，我想和妈妈做一夜。"},
        {speaker = "贝丝妲", text = "妈妈答应你。不过为了以防万一，我叫普雷希派了两位魅魔国军方人员，那两位打仗很专业，能够帮助你对付贵族军队。"},
        {speaker = "罗卡尔", text = "加入的人已经够多了，又来2个，如果是女的，我又要被榨。"},
        {speaker = "贝丝妲", text = "是你想要的，连姐姐们都不放过。"},
        {speaker = "罗卡尔", text = "不过安洁莉卡姐姐不愿意和我做，她好像是女同。"},
        {speaker = "贝丝妲", text = "很久都知道了，连我都上。"},
        {speaker = "罗卡尔", text = "这样啊。妈妈，我决定弄一个乱交派对玩玩，让大家亲密交流。"},
        {speaker = "贝丝妲", text = "你这个变态，这么忍心把妈妈给别人玩？"},
        {speaker = "罗卡尔", text = "你不是经常和卡洛斯玩吗？别认为我不知道，你还和舅舅经常搞，我也算是理解了洛基的爱好。"},
        {speaker = "贝丝妲", text = "你想被绿？好呀，今天晚上举行派对，让孙子们当着你面轮我，你可别后悔。"},
        {speaker = "罗卡尔", text = "我知道，今天晚上好好玩玩，明天出发。如果有机会，想和芙萝娅和温蒂姐姐做。"},
    },
}

return M
