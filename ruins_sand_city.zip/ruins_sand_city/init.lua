-- ==========================================
-- 废墟沙城（Ruins Sand City）副本入口
-- 统一注册：普通/精英/领主怪物、卡牌、饰品、副本结构
-- ==========================================

local Ruins = {}

-- 加载各模块
local Common  = require("ruins_sand_city.monsters.common")
local Elite   = require("ruins_sand_city.monsters.elite")
local Lord    = require("ruins_sand_city.monsters.lord")
local Cards   = require("ruins_sand_city.cards")
local Equip   = require("ruins_sand_city.equipment")
local Dungeon = require("ruins_sand_city.dungeon")

-- 收集全部怪物
local monsters = {}
for _, m in pairs(Common)  do table.insert(monsters, m) end
for _, m in pairs(Elite)   do table.insert(monsters, m) end
for _, m in pairs(Lord)    do table.insert(monsters, m) end

-- 收集全部卡牌 / 饰品
local cards, equipment = {}, {}
for _, c in pairs(Cards.cards) do table.insert(cards, c) end
for _, e in pairs(Equip.equipment) do table.insert(equipment, e) end

-- 注册函数（由游戏引擎提供）
function Ruins:register(game)
    -- 等级上限提升至20级
    game:setMaxLevel(Dungeon.maxLevel)

    -- 注册副本
    game:registerDungeon(Dungeon)

    -- 注册怪物
    for _, m in ipairs(monsters) do
        game:registerCharacter(m)   -- 怪物复用角色注册接口
    end

    -- 注册卡牌掉落（首次击败后解锁）
    for _, c in ipairs(cards) do
        game:registerShopCard(c, "villa_shop")
    end

    -- 注册饰品掉落
    for _, e in ipairs(equipment) do
        game:registerEquipment(e)
    end

    -- 注册解锁事件（通关兽人地下城勇士级后触发）
    game:registerUnlockEvent(Dungeon.unlockEvent)
end

return Ruins
