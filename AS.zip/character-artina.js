// 亚缇娜 - 魅影突击队狙击手
(function () {
  'use strict';

  const SKILL_SNIPE = 'snipe-target';
  const SKILL_CHARGE = 'charged-bullet';

  window.ArtinaSkills = {
    id: 'artina',
    displayName: '亚缇娜',
    gender: 'female',
    title: '魅影突击队狙击手',

    baseStats: {
      attack: 3, magic: 3, speed: 4, hp: 36,
      maxRage: 1, maxHand: 4,
      drawPerTurnBase: 2, drawPerTurnBonus: 2, // 基础2+2
      initDrawBase: 4, initDrawBonus: 2         // 初始4+2
    },

    // ── 状态初始化（每回合） ──
    onTurnStart: function (context) {
      // 蓄力子弹：本回合记录的花色
      context.setTemp(this, 'recordedSuits', []);
      context.setTemp(this, 'chargeMultiplier', 0);
      context.setTemp(this, 'snipeTargets', {}); // {enemyId: suit}
    },

    // ⚔️ 狙击目标（出牌阶段限一次）
    // 指定敌方一名角色，展示其一张手牌。若你手中此花色牌数 > 该目标，你用单体杀时其不可响应
    onPlayPhase: function (context) {
      if (context.hasUsedSkill(SKILL_SNIPE)) return;

      const enemies = context.getEnemies();
      if (enemies.length === 0) return;

      // AI：优先选手牌多、且我方能克制的目标
      const target = context.chooseSnipeTarget(enemies);
      if (!target) return;

      // 展示目标一张手牌
      const shownCard = context.showRandomHandCard(target);
      if (!shownCard) return;

      const suit = shownCard.suit; // 'heart' | 'diamond' | 'club' | 'spade'
      const myCount = context.countSuitInHand(context.self, suit);

      // 若我方此花色牌数 > 目标，标记该目标为"不可响应杀"
      if (myCount > 1) { // 严格大于（目标自己那张算1，我方需>=2）
        const recorded = context.getTemp(this, 'snipeTargets') || {};
        recorded[target.id] = suit;
        context.setTemp(this, 'snipeTargets', recorded);
      }

      context.markSkillUsed(SKILL_SNIPE);
      context.log('亚缇娜：「让我看看敌人在哪。」');
      context.logDetail(`${target.displayName} 被狙击，展示花色：${context.suitName(suit)}`);
    },

    // ⭐ 蓄力子弹（锁定技）
    // 本回合首次使用每种花色的牌时记录该花色。
    // 使用的下一张实体单体【杀】造成伤害翻倍，每记录一种花色额外+1倍。
    // 使用实体单体杀后清除标记。记录花色显示在头像上。
    onCardUsed: function (context, card) {
      if (!card || card.isVirtual) return; // 仅实体牌

      const recorded = context.getTemp(this, 'recordedSuits') || [];
      const suit = card.suit;

      // 首次使用每种花色 → 记录
      if (suit && !recorded.includes(suit)) {
        recorded.push(suit);
        context.setTemp(this, 'recordedSuits', recorded);
        context.updateAvatarBadge(context.self, recorded); // 头像显示记录花色
        context.logDetail(`亚缇娜 蓄力子弹：记录花色 ${context.suitName(suit)}`);
      }
    },

    // 实体单体【杀】造成伤害前：应用倍数
    onBeforeKillDamage: function (context, killCard, target) {
      if (!killCard || killCard.isVirtual || killCard.isArea) return; // 仅实体单体杀

      // 狙击目标：若目标被标记同花色，不可响应
      const snipeTargets = context.getTemp(this, 'snipeTargets') || {};
      if (snipeTargets[target.id]) {
        context.setUnresponseable(target);
      }

      // 蓄力倍数：基础2倍 + 每记录一种花色+1倍
      const recorded = context.getTemp(this, 'recordedSuits') || [];
      const multiplier = 2 + recorded.length; // 每记录一种额外+1
      context.setTemp(this, 'chargeMultiplier', multiplier);

      return { damageMultiplier: multiplier };
    },

    // 实体单体【杀】造成伤害后：清除标记 + 台词
    onKillDamageDealt: function (context, killCard, target, amount) {
      if (!killCard || killCard.isVirtual || killCard.isArea) return;

      context.log('亚缇娜：「耶，打中了要害。」');

      // 清除蓄力标记
      context.setTemp(this, 'recordedSuits', []);
      context.setTemp(this, 'chargeMultiplier', 0);
      context.updateAvatarBadge(context.self, []);
    },

    // 回合结束：清理（蓄力标记已在用杀后清除，此处兜底）
    onTurnEnd: function (context) {
      context.setTemp(this, 'recordedSuits', []);
      context.setTemp(this, 'chargeMultiplier', 0);
      context.setTemp(this, 'snipeTargets', {});
      context.updateAvatarBadge(context.self, []);
    }
  };
})();
