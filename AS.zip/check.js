const fs = require('fs');

const files = ['character-artina.js', 'character-maria.js'];

console.log('═'.repeat(50));
console.log('  静态检查：语法 / 行数 / 接口对照');
console.log('═'.repeat(50));

const allGood = files.map(file => {
  const code = fs.readFileSync(file, 'utf8');
  const lines = code.split('\n').length;
  let syntaxOk = true;
  let syntaxErr = '';

  // 1. 语法检查
  try {
    new Function(code);
  } catch (e) {
    syntaxOk = false;
    syntaxErr = e.message;
  }

  // 2. 导出对象检查
  const hasWindowExport = /window\.(ArtinaSkills|MariaSkills)/.test(code);

  // 3. 接口调用提取（context.xxx）
  const calledMethods = new Set();
  code.replace(/context\.(\w+)/g, (_, m) => calledMethods.add(m));

  console.log(`\n📄 ${file}`);
  console.log(`   行数: ${lines} ${lines <= 200 ? '✅' : '⚠️ 超200行'}`);
  console.log(`   语法: ${syntaxOk ? '✅ 通过' : '❌ ' + syntaxErr}`);
  console.log(`   导出: ${hasWindowExport ? '✅ window.xxxSkills' : '❌ 未找到导出'}`);
  console.log(`   context 接口(${calledMethods.size}个): ${[...calledMethods].join(', ')}`);

  return syntaxOk && lines <= 200 && hasWindowExport;
});

console.log('\n' + '═'.repeat(50));
console.log(allGood.every(Boolean) ? '✅ 全部检查通过' : '⚠️ 存在问题，请查看上方');
console.log('═'.repeat(50));
