// 玛利亚 - 魅影突击队支援兵
(function () {
  'use strict';

  const SKILL_DIVINE = 'divine-number';
  const SKILL_BLESSING = 'honor-blessing';

  window.MariaSkills = {
    id: 'maria',
    displayName: '玛利亚',
    gender: 'female',
    title: '魅影突击队支援兵',

    baseStats: {
      attack: 2, magic: 3, speed: 4, hp: 38,
      maxRage: 2, maxHand: 3,
      drawPerTurnBase: 2, drawPerTurnBonus: 3, // 基础2+3
      initDrawBase: 4, initDrawBonus: 1         // 初始4+1
    },

    // ── 状态初始化（每回合） ──
    onTurnStart: function (context) {
      // 神数咒语：每回合使用牌计数；标记数持久（回合结束才消失）
      context.setTemp(this, 'cardsUsedThisRound', 0);
    },

    // ⭐ 神数咒语（锁定技）
    // 出牌阶段首次使用牌时获得1枚神数标记。
    // 使用牌数达到标记数时，摸等同于标记数的牌，并再得1枚标记，重新计数。
    // 每有1枚标记，攻击力、魔力各+1。回合结束时标记消失。
    onCardUsed: function (context, card) {
      if (!card) return;

      // 首次使用牌 → 获得第1枚标记
      let marks = context.getMarkCount(context.self, SKILL_DIVINE);
      let used = (context.getTemp(this, 'cardsUsedThisRound') || 0) + 1;
      context.setTemp(this, 'cardsUsedThisRound', used);

      if (marks === 0 && used === 1) {
        context.addMark(context.self, SKILL_DIVINE, 1);
        marks = 1;
        context.log('玛利亚：「盖亚妮丝女神请你祝福我。」');
      }

      // 使用牌数达到标记数 → 摸标记数张牌，标记+1，重新计数
      if (marks > 0 && used >= marks) {
        context.drawCards(context.self, marks);
        context.addMark(context.self, SKILL_DIVINE, 1);
        context.setTemp(this, 'cardsUsedThisRound', 0); // 重新计数
        context.logDetail(`神数咒语：摸到 ${marks} 张牌，神数标记 +1`);
      }

      // 每有1枚标记，攻+1、魔+1（实时计算属性加成）
      context.applyStatBonus(context.self, {
        attack: marks,
        magic: marks
      });
    },

    // ⚔️ 荣誉祝福（出牌阶段限一次）
    // 弃置1~4张不同花色的牌，我方全体角色根据你的攻击力、魔力、速度获得对应提升。
    // 持续回合数 = 弃置牌数（每弃1张持续1回合）。
    onPlayPhase: function (context) {
      if (context.hasUsedSkill(SKILL_BLESSING)) return;

      // 收集手牌中不同花色的牌（最多4张，每张花色不同）
      const hand = context.getHand(context.self);
      const bySuit = {};
      hand.forEach(c => { if (c.suit && !bySuit[c.suit]) bySuit[c.suit] = c; });
      const distinctSuits = Object.keys(bySuit);

      if (distinctSuits.length === 0) return;

      // AI：按攻/魔/速综合收益选最优组合（1~4张不同花色）
      const chosen = context.chooseBlessingCards(hand, distinctSuits);
      if (!chosen || chosen.length === 0) return;

      // 弃置
      context.discardCards(context.self, chosen);
      const count = chosen.length; // 持续回合数

      // 我方全体获得属性提升（基于玛利亚当前攻/魔/速）
      const selfStats = context.getStats(context.self);
      const allies = context.getAllies(context.self);
      allies.forEach(ally => {
        context.applyBuff(ally, {
          attack: selfStats.attack,
          magic: selfStats.magic,
          speed: selfStats.speed
        }, count); // 持续 count 回合
      });

      context.markSkillUsed(SKILL_BLESSING);
      context.log('玛利亚：「神圣的祝福增强我们斗志。」');
      context.logDetail(`荣誉祝福：弃 ${count} 张，全体属性提升 ${count} 回合`);
    },

    // 回合结束时：神数咒语标记消失
    onTurnEnd: function (context) {
      context.clearMarks(context.self, SKILL_DIVINE);
      context.setTemp(this, 'cardsUsedThisRound', 0);
      // 清除属性加成（由 applyStatBonus 的回合计数自动衰减，此处兜底）
      context.refreshAllBuffs(context.self);
    }
  };
})();
