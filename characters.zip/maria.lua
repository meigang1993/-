-- ==========================================
-- 角色：玛利亚 (Maria)
-- 定位：支援兵
-- ==========================================
local maria = {
    -- 基础信息
    name = "玛利亚",
    gender = "女",
    identity = "魅魔国魅影突击队支援兵",
    isCombatant = true,

    -- 0级基础属性
    baseAttributes = {
        attack = 2,
        magic = 3,
        speed = 4,
        hp = 38,
        maxKillingIntent = 2,
        maxHandSize = 3,
        drawPerTurn = {base = 2, bonus = 3},  -- 每回合摸牌数 基础2+3
        initialDraw  = {base = 4, bonus = 1}   -- 初始摸牌数 基础4+1
    },

    -- 技能定义
    skills = {
        -- ⚔️ 荣誉祝福
        honorBlessing = {
            type = "active",
            phase = "play",
            limit = "once_per_phase",
            prompt = "神圣的祝福增强我们斗志。",

            canUse = function(self, player)
                return not player:hasFlag("honor_blessing_used")
            end,

            onUse = function(self, player)
                -- 选择1至4张不同花色的牌
                local cards = player:chooseCards(
                    player:getHandCards(),
                    {min = 1, max = 4},
                    "选择要弃置的牌（不同花色）"
                )

                if cards and #cards > 0 then
                    -- 检查花色是否不同
                    local suits = {}
                    for _, card in ipairs(cards) do
                        local suit = card:getSuit()
                        if suits[suit] then
                            player:notify("必须选择不同花色的牌！")
                            return
                        end
                        suits[suit] = true
                    end

                    local discardCount = #cards

                    -- 弃置牌
                    player:discardCards(cards)

                    -- 我方全体获得属性提升
                    local allies = player:getAllies()
                    for _, ally in ipairs(allies) do
                        ally:addBuff({
                            attack = player:getAttack(),
                            magic  = player:getMagic(),
                            speed  = player:getSpeed(),
                            duration = discardCount  -- 持续回合数等于弃置牌数
                        })
                    end

                    player:setFlag("honor_blessing_used", true)
                    player:speak("神圣的祝福增强我们斗志。")
                end
            end
        },

        -- ⭐ 神数咒语
        divineNumberSpell = {
            type = "locked",
            prompt = "盖亚妮丝女神请你祝福我。",

            markCount = 0,      -- 神数标记数
            usedThisTurn = 0,   -- 本回合使用牌数

            onPhaseStart = function(self, player)
                self.usedThisTurn = 0
            end,

            onTurnEnd = function(self, player)
                -- 回合结束时标记消失
                self.markCount = 0
                player:removeBuff("divine_number")
                player:speak("盖亚妮丝女神请你祝福我。")
            end,

            onUseCard = function(self, player, card)
                self.usedThisTurn = self.usedThisTurn + 1

                -- 首次使用牌时获得一枚神数标记
                if self.usedThisTurn == 1 and self.markCount == 0 then
                    self.markCount = 1
                end

                -- 当使用牌数达到标记数时
                if self.usedThisTurn >= self.markCount and self.markCount > 0 then
                    -- 摸等同于标记数的牌
                    player:drawCards(self.markCount)

                    -- 再次获得一枚标记
                    self.markCount = self.markCount + 1

                    -- 每有一枚标记，攻击力和魔力各+1
                    player:addBuff({
                        attack = self.markCount,
                        magic  = self.markCount,
                        duration = 1  -- 仅本回合有效
                    })

                    -- 重新计数
                    self.usedThisTurn = 0
                end
            end
        }
    }
}

return maria
