-- 角色注册入口
local artina = require("artina")
local maria = require("maria")

Game:registerCharacter(artina)
Game:registerCharacter(maria)
