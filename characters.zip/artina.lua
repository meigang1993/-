-- ==========================================
-- 角色：亚缇娜 (Artina)
-- 定位：狙击手
-- ==========================================
local artina = {
    -- 基础信息
    name = "亚缇娜",
    gender = "女",
    identity = "魅魔国魅影突击队狙击手",
    isCombatant = true,

    -- 0级基础属性
    baseAttributes = {
        attack = 3,
        magic = 3,
        speed = 4,
        hp = 36,
        maxKillingIntent = 1,
        maxHandSize = 4,
        drawPerTurn = {base = 2, bonus = 2},  -- 每回合摸牌数 基础2+2
        initialDraw  = {base = 4, bonus = 2}   -- 初始摸牌数 基础4+2
    },

    -- 技能定义
    skills = {
        -- ⚔️ 狙击目标
        snipeTarget = {
            type = "active",
            phase = "play",
            limit = "once_per_phase",
            prompt = "让我看看敌人在哪。",

            canUse = function(self, player)
                -- 出牌阶段限一次，且未使用过
                return not player:hasFlag("snipe_target_used")
            end,

            onUse = function(self, player)
                -- 选择敌方目标
                local targets = player:getEnemies()
                local target = player:chooseTarget(targets, "选择狙击目标")

                if target then
                    -- 展示目标一张手牌
                    local shownCard = target:showRandomHandCard()

                    if shownCard then
                        local suit = shownCard:getSuit()
                        local playerSuitCount = player:countHandCardsBySuit(suit)
                        local targetSuitCount = target:countHandCardsBySuit(suit)

                        -- 若手中此花色牌数大于目标
                        if playerSuitCount > targetSuitCount then
                            -- 标记：对目标使用【杀】时不可响应
                            player:setFlag("snipe_target", target)
                            player:setFlag("snipe_target_suit", suit)
                        end

                        player:setFlag("snipe_target_used", true)
                    end
                end
            end,

            -- 修改【杀】的响应规则
            onModifySlash = function(self, player, slash, target)
                local snipeTarget = player:getFlag("snipe_target")
                if snipeTarget and snipeTarget == target then
                    return {cannotRespond = true}
                end
                return nil
            end
        },

        -- ⭐ 蓄力子弹
        chargedBullet = {
            type = "locked",
            prompt = "耶，打中了要害。",

            -- 记录的花色
            recordedSuits = {},
            -- 蓄力状态
            charged = false,

            onPhaseStart = function(self, player)
                -- 回合开始时重置
                self.recordedSuits = {}
                self.charged = false
                player:clearAvatarMark("charged_suits")
            end,

            -- 首次使用每种花色的牌时记录
            onUseCard = function(self, player, card)
                local suit = card:getSuit()

                if not self.recordedSuits[suit] then
                    -- 首次使用此花色，记录
                    self.recordedSuits[suit] = true
                    player:addAvatarMark("charged_suits", suit)
                end
            end,

            -- 修改【杀】的伤害
            onDamageCalc = function(self, player, source, target, damage, card)
                if not self.charged and card and card:isSlash() and card:isPhysical() and card:isSingleTarget() then
                    -- 下一张实体单体【杀】
                    self.charged = true

                    -- 基础翻倍 + 每记录一种花色额外一倍
                    local suitCount = 0
                    for _ in pairs(self.recordedSuits) do
                        suitCount = suitCount + 1
                    end

                    local multiplier = 2 + suitCount
                    player:speak("耶，打中了要害。")

                    return damage * multiplier
                end

                -- 使用实体单体【杀】后清除标记
                if card and card:isSlash() and card:isPhysical() and card:isSingleTarget() then
                    self.charged = false
                    self.recordedSuits = {}
                    player:clearAvatarMark("charged_suits")
                end

                return damage
            end
        }
    }
}

return artina
