// 在 prepare 函数中，现有逻辑之后、return 之前加入：
if (unit.ai && [
  'fae-soldier','noble-sniper','melkar-tank','attack-drone',
  'mech-ai-dragon','wither-unit-1312','assassin-hilde',
  'attack-helicopter','armored-transport'
].includes(unit.ai)) {
  return window.RuinsEnemySkills && window.RuinsEnemySkills.prepare
    ? window.RuinsEnemySkills.prepare(state, unit, damage, nextAnim)
    : false;
}