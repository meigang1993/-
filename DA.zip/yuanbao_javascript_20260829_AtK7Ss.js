if (window.RuinsEnemySkills && window.RuinsEnemySkills.endTurn) {
  window.RuinsEnemySkills.endTurn(state, unit);
}