window.ArthelinaMariaSkills = (function () {
  'use strict';

  var alive = function (u) { return u && u.hp > 0; };
  var isKill = function (c) {
    return c && (c.type === 'slash' || /杀(?:（[^）]*）)?$/.test(c.name || ''));
  };
  var line = function (state, unit, name) {
    if (window.BattleLines && window.BattleLines.skill) {
      window.BattleLines.skill(state, unit, name);
    }
  };

  function artheliaSnipe(state, actor) {
    if (actor.ref !== 'arthelina' || actor.usedSnipeTarget) return;
    var enemies = state.battle.enemies.filter(alive);
    if (!enemies.length) return;
    var target = enemies[Math.floor(Math.random() * enemies.length)];
    if (!target.hand || !target.hand.length) return;
    var shown = target.hand[Math.floor(Math.random() * target.hand.length)];
    actor.usedSnipeTarget = true;
    actor.snipeTargetUid = target.uid;
    actor.snipeSuit = shown.suit;
    line(state, actor, '让我看看敌人在哪。');
    window.BattleLog.add(state, actor.name + ' 锁定了' + target.name + '，展示了' + (shown.suit || '') + shown.name + '。');
  }

  function artheliaChargeDamage(state, actor, amount, card) {
    if (!amount || actor.ref !== 'arthelina' || !isKill(card)) return amount;
    if (actor.snipeTargetUid && card.targetUid === actor.snipeTargetUid) {
      var suitCount = actor.recordedSuits ? Object.keys(actor.recordedSuits).length : 0;
      var mult = 2 + suitCount;
      line(state, actor, '耶，打中了要害。');
      window.BattleLog.add(state, actor.name + ' 蓄力子弹触发，伤害×' + mult + '！');
      return amount * mult;
    }
    return amount;
  }

  function artheliaRecordSuit(state, actor, card) {
    if (actor.ref !== 'arthelina' || !card) return;
    if (!actor.recordedSuits) actor.recordedSuits = {};
    if (!actor.recordedSuits[card.suit]) {
      actor.recordedSuits[card.suit] = true;
      if (typeof actor.updateAvatarBadge === 'function') {
        actor.updateAvatarBadge(Object.keys(actor.recordedSuits));
      }
    }
  }

  function mariaDivineNumber(state, actor) {
    if (actor.ref !== 'maria') return;
    if (!actor.divineMarks) actor.divineMarks = 0;
    if (!actor.cardsUsedThisTurn) actor.cardsUsedThisTurn = 0;
    if (actor.cardsUsedThisTurn === 0) {
      actor.divineMarks++;
      line(state, actor, '盖亚妮丝女神请你祝福我。');
    }
    actor.cardsUsedThisTurn++;
    if (actor.cardsUsedThisTurn >= actor.divineMarks) {
      actor.divineMarks++;
      actor.cardsUsedThisTurn = 0;
      window.BattleLog.add(state, actor.name + ' 神数咒语触发，摸牌。');
    }
    actor.tempAttackBonus = (actor.divineMarks - 1);
    actor.tempMagicBonus = (actor.divineMarks - 1);
  }

  function mariaHonorBlessing(state, actor, card, deps, ctx) {
    if (actor.ref !== 'maria' || actor.usedHonorBlessing) return false;
    return false;
  }

  function mariaTurnEnd(state, unit) {
    if (unit.ref !== 'maria') return;
    unit.divineMarks = 0;
    unit.cardsUsedThisTurn = 0;
    unit.tempAttackBonus = 0;
    unit.tempMagicBonus = 0;
  }

  function beforeCardPlayed(state, actor, card) {
    artheliaSnipe(state, actor);
    artheliaRecordSuit(state, actor, card);
    mariaDivineNumber(state, actor);
  }

  function modifyDamage(state, actor, amount, card) {
    return artheliaChargeDamage(state, actor, amount, card);
  }

  function handleSpecialCard(state, actor, target, card, deps, ctx) {
    return mariaHonorBlessing(state, actor, card, deps, ctx);
  }

  function beginTurn(state, unit) {
    mariaTurnEnd(state, unit);
  }

  return {
    beforeCardPlayed: beforeCardPlayed,
    modifyDamage: modifyDamage,
    handleSpecialCard: handleSpecialCard,
    beginTurn: beginTurn
  };
})();