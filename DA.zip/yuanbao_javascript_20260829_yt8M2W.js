window.RuinsEnemySkills = (function () {
  'use strict';

  var alive = function (u) { return u && u.hp > 0; };
  var stat = function (unit, key) {
    var base = (unit.stats && unit.stats[key]) || 0;
    if (key === 'attack') base += (unit.tempAttack || 0);
    if (key === 'magic') base += (unit.tempMagic || 0);
    return base;
  };

  function faeSoldierPrepare(state, unit, damage) {
    if ((unit.ai !== 'fae-soldier' && unit.ref !== 'fae-soldier') || unit.usedMine) return false;
    var targets = state.battle.allies.filter(alive);
    if (!targets.length) return false;
    unit.statuses = unit.statuses || [];
    if (!unit.statuses.includes('mine')) {
      unit.statuses.push('mine');
      unit.usedMine = true;
    }
    if (window.BattleLines && window.BattleLines.skill) {
      window.BattleLines.skill(state, unit, '放置地雷');
    }
    window.BattleLog.add(state, unit.name + ' 放置了地雷。');
    return true;
  }

  function nobleSniperPrepare(state, unit, damage) {
    if (unit.ai !== 'noble-sniper' || unit.usedSnipe) return false;
    var targets = state.battle.allies.filter(alive);
    if (!targets.length) return false;
    var target = targets.reduce(function (w, u) { return u.hp < w.hp ? u : w; }, targets[0]);
    unit.usedSnipe = true;
    if (window.BattleLines && window.BattleLines.skill) {
      window.BattleLines.skill(state, unit, '穿甲射击');
    }
    window.BattleLog.add(state, unit.name + ' 穿甲射击' + target.name + '。');
    if (typeof damage === 'function') {
      damage(state, target, stat(unit, 'attack') + 2, '穿甲射击', unit, {
        name: '穿甲射击', type: 'skill', ignoreArmor: true
      });
    }
    return true;
  }

  function melkarModify(state, actor, amount, card) {
    if (actor.ai !== 'melkar-tank') return amount;
    if (card && !card.realDamage && amount > 0) {
      window.BattleLog.add(state, actor.name + ' 坚硬装甲伤害-1。');
      return Math.max(0, amount - 1);
    }
    return amount;
  }

  function dronePrepare(state, unit, damage) {
    if (unit.ai !== 'attack-drone' || unit.usedLockOn) return false;
    var targets = state.battle.allies.filter(alive);
    if (!targets.length) return false;
    unit.lockOnTarget = window.GameRandom.sample(targets, state).uid;
    unit.usedLockOn = true;
    if (window.BattleLines && window.BattleLines.skill) {
      window.BattleLines.skill(state, unit, '锁定攻击');
    }
    return true;
  }

  function dragonPrepare(state, unit, damage) {
    if (unit.ai !== 'mech-ai-dragon' || unit.usedTactical) return false;
    unit.tacticalDouble = true;
    unit.usedTactical = true;
    if (window.BattleLines && window.BattleLines.skill) {
      window.BattleLines.skill(state, unit, '战术翻倍');
    }
    return true;
  }

  function witherPrepare(state, unit, damage) {
    if (unit.ai !== 'wither-unit-1312' || unit.usedWitherSkill) return false;
    var targets = state.battle.allies.filter(alive);
    if (!targets.length) return false;
    var target = window.GameRandom.sample(targets, state);
    target.statuses = target.statuses || [];
    if (!target.statuses.includes('confusion')) target.statuses.push('confusion');
    var drain = Math.min(target.hp, stat(unit, 'magic'));
    if (drain > 0) {
      target.hp = Math.max(0, target.hp - drain);
      unit.hp = Math.min(unit.maxHp, unit.hp + drain);
    }
    unit.usedWitherSkill = true;
    if (window.BattleLines && window.BattleLines.skill) {
      window.BattleLines.skill(state, unit, '外神之眼');
    }
    return true;
  }

  function hildePrepare(state, unit, damage) {
    if (unit.ai !== 'assassin-hilde' || unit.usedStealth) return false;
    var targets = state.battle.allies.filter(alive);
    if (!targets.length) return false;
    var target = targets.find(function (u) { return u.hp <= u.maxHp * 0.3; }) || window.GameRandom.sample(targets, state);
    unit.usedStealth = true;
    if (window.BattleLines && window.BattleLines.skill) {
      window.BattleLines.skill(state, unit, '潜行刺杀');
    }
    if (typeof damage === 'function') {
      damage(state, target, stat(unit, 'attack') + (target.hp <= target.maxHp * 0.3 ? 4 : 0), '潜行刺杀', unit, {
        name: '潜行刺杀', type: 'skill'
      });
    }
    return true;
  }

  function heliPrepare(state, unit, damage) {
    if (unit.ai !== 'attack-helicopter' || unit.usedBarrage) return false;
    var targets = state.battle.allies.filter(alive);
    if (!targets.length) return false;
    unit.usedBarrage = true;
    if (window.BattleLines && window.BattleLines.skill) {
      window.BattleLines.skill(state, unit, '弹幕扫射');
    }
    var i;
    for (i = 0; i < targets.length; i++) {
      if (typeof damage === 'function') {
        damage(state, targets[i], 2, '弹幕扫射', unit, { name: '弹幕扫射', type: 'skill' });
      }
    }
    return true;
  }

  function armorModify(state, actor, amount, card) {
    if (actor.ai !== 'armored-transport') return amount;
    if (card && !card.realDamage && amount > 0) {
      window.BattleLog.add(state, actor.name + ' 坚硬装甲伤害-1。');
      return Math.max(0, amount - 1);
    }
    return amount;
  }

  function prepare(state, unit, damage, nextAnim) {
    var ai = unit.ai || unit.ref;
    switch (ai) {
      case 'fae-soldier': return faeSoldierPrepare(state, unit, damage);
      case 'noble-sniper': return nobleSniperPrepare(state, unit, damage);
      case 'attack-drone': return dronePrepare(state, unit, damage);
      case 'mech-ai-dragon': return dragonPrepare(state, unit, damage);
      case 'wither-unit-1312': return witherPrepare(state, unit, damage);
      case 'assassin-hilde': return hildePrepare(state, unit, damage);
      case 'attack-helicopter': return heliPrepare(state, unit, damage);
      default: return false;
    }
  }

  function modifyDamage(state, actor, amount, card) {
    var ai = actor.ai || actor.ref;
    if (ai === 'melkar-tank') return melkarModify(state, actor, amount, card);
    if (ai === 'armored-transport') return armorModify(state, actor, amount, card);
    return amount;
  }

  function endTurn(state, unit) {
    var ai = unit.ai || unit.ref;
    if (ai === 'fae-soldier') unit.usedMine = false;
    if (ai === 'noble-sniper') unit.usedSnipe = false;
    if (ai === 'attack-drone') { unit.usedLockOn = false; unit.lockOnTarget = null; }
    if (ai === 'mech-ai-dragon') { unit.usedTactical = false; unit.tacticalDouble = false; }
    if (ai === 'wither-unit-1312') unit.usedWitherSkill = false;
    if (ai === 'assassin-hilde') unit.usedStealth = false;
    if (ai === 'attack-helicopter') unit.usedBarrage = false;
  }

  return {
    prepare: prepare,
    modifyDamage: modifyDamage,
    endTurn: endTurn
  };
})();