// 废墟沙城掉落饰品
(function () {
  'use strict';
  var accessories = [
    {
      id: 'propeller', name: '推进器',
      description: '速度+2，出牌阶段首次移动不消耗行动力。',
      stats: { speed: 2 }, effects: { freeFirstMove: true }
    },
    {
      id: 'smart-brain', name: '智能大脑',
      description: '魔力+3，每回合首次技能伤害+1。',
      stats: { magic: 3 }, effects: { firstSkillDamageBonus: 1 }
    },
    {
      id: 'succubus-fork', name: '魅魔钢叉',
      description: '攻击力+2，杀的伤害+1。',
      stats: { attack: 2 }, effects: { killDamageBonus: 1 }
    },
    {
      id: 'pink-succubus-outfit', name: '粉色魅魔装',
      description: '生命值+10，受到男性角色伤害-1。',
      stats: { hp: 10 }, effects: { reduceDamageFromMale: 1 }
    },
    {
      id: 'ice-twin-daggers', name: '冰心双刺剑',
      description: '攻击力+3，速度+1，攻击有30%概率附加冰冻。',
      stats: { attack: 3, speed: 1 }, effects: { freezeChance: 0.3 }
    },
    {
      id: 'assassin-suit', name: '刺客胶衣',
      description: '速度+2，手牌上限+1，被锁定技指定的概率降低。',
      stats: { speed: 2, handLimit: 1 }, effects: { reduceTargetChance: true }
    },
    {
      id: 'rotor', name: '螺旋桨',
      description: '速度+3，每回合可多摸1张牌。',
      stats: { speed: 3 }, effects: { extraDraw: 1 }
    },
    {
      id: 'missile-launcher', name: '导弹发射器',
      description: '攻击力+4，杀的伤害+2，但每回合摸牌数-1。',
      stats: { attack: 4 }, effects: { killDamageBonus: 2, drawPenalty: 1 }
    },
    {
      id: 'supply-cargo', name: '物资货物',
      description: '生命值+15，手牌上限+2。',
      stats: { hp: 15, handLimit: 2 }
    },
    {
      id: 'armory', name: '武器库',
      description: '攻击力+2，魔力+2，杀意上限+1。',
      stats: { attack: 2, magic: 2, bloodlust: 1 }
    }
  ];
  if (typeof window.GameData === 'undefined') window.GameData = {};
  if (!window.GameData.futureAccessories) window.GameData.futureAccessories = [];
  window.GameData.futureAccessories.push.apply(window.GameData.futureAccessories, accessories);
})();