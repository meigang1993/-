// 追加废墟沙城怪物
if (typeof window.GameData !== 'undefined' && window.GameData.futureEnemies) {
  window.GameData.futureEnemies.push(
    { id: 'fae-soldier', name: '斐族军士兵', hp: 28, attack: 3, speed: 2, skills: ['place-mine'] },
    { id: 'noble-sniper', name: '贵族军狙击手', hp: 24, attack: 5, speed: 1, skills: ['piercing-shot'] },
    { id: 'melkar-tank', name: '梅尔卡坦克', hp: 50, attack: 4, speed: 0, skills: ['heavy-armor'] },
    { id: 'attack-drone', name: '攻击型无人机', hp: 20, attack: 3, speed: 3, skills: ['lock-on'] },
    { id: 'mech-ai-dragon', name: '机械AI龙', hp: 80, attack: 6, speed: 3, skills: ['tactical-double'] },
    { id: 'wither-unit-1312', name: 'XX型凋零者1312号', hp: 100, attack: 5, speed: 2, skills: ['outer-god-eye'] },
    { id: 'assassin-hilde', name: '内英组杀手希尔德', hp: 35, attack: 6, speed: 5, skills: ['stealth-strike'] },
    { id: 'attack-helicopter', name: '武装直升机', hp: 45, attack: 5, speed: 4, skills: ['barrage'] },
    { id: 'armored-transport', name: '装甲运输车', hp: 60, attack: 3, speed: 1, skills: ['hard-armor'] }
  );
}