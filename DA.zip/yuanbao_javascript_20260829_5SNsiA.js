modifyDamage: function (state, actor, amount, card) {
  var base = hooks.modifyDamage(state, actor, amount, card);
  return (window.RuinsEnemySkills && window.RuinsEnemySkills.modifyDamage)
    ? window.RuinsEnemySkills.modifyDamage(state, actor, base, card)
    : base;
}