// 废墟沙城掉落卡牌
(function () {
  'use strict';
  var cards = [
    {
      id: 'pin-sha', name: '拼杀', type: 'kill',
      description: '对一名敌方造成1点伤害，若目标手牌数大于你，此杀不可被闪响应。',
      effects: { damage: 1, ignoreDodgeIfMoreHand: true }
    },
    {
      id: 'mo-zhi-lian-sha', name: '魔之连杀', type: 'kill',
      description: '对一名敌方造成1点伤害，若击杀目标，可立即对另一名敌方再出一张杀。',
      effects: { damage: 1, chainOnKill: true }
    },
    {
      id: 'mei-huo-shu', name: '魅惑术', type: 'skill',
      description: '选择一名敌方，令其本回合内你的杀对其伤害+1。',
      effects: { buffSelfKillDamage: 1, turns: 1 }
    },
    {
      id: 'mei-sha', name: '魅杀', type: 'kill',
      description: '对一名敌方造成2点伤害，若为男性目标，伤害额外+1。',
      effects: { damage: 2, extraDamageVsMale: 1 }
    },
    {
      id: 'tou-xi', name: '偷袭', type: 'kill',
      description: '出牌阶段限一次，对一名敌方造成1点伤害，无视其防具。',
      effects: { damage: 1, ignoreArmor: true }
    },
    {
      id: 'bing-dong-shu', name: '冰冻术', type: 'skill',
      description: '令一名敌方获得冰冻状态，跳过其下回合出牌阶段。',
      effects: { applyStatus: 'freeze', turns: 1 }
    },
    {
      id: 'liu-xing-sha', name: '流星杀', type: 'kill',
      description: '对一名敌方造成3点伤害，消耗2点杀意。',
      effects: { damage: 3, costBloodlust: 2 }
    },
    {
      id: 'xi-mo-sha', name: '吸魔杀', type: 'kill',
      description: '对一名敌方造成1点伤害，并吸取其1点魔力值。',
      effects: { damage: 1, drainMagic: 1 }
    },
    {
      id: 'wu-zi-si-fen', name: '物资私分', type: 'skill',
      description: '摸2张牌，然后弃1张牌。',
      effects: { draw: 2, discard: 1 }
    },
    {
      id: 'qiang-lin-dan-yu', name: '枪林弹雨', type: 'skill',
      description: '对所有敌方造成1点伤害。',
      effects: { damage: 1, aoe: true }
    }
  ];
  if (typeof window.GameData === 'undefined') window.GameData = {};
  if (!window.GameData.futureCards) window.GameData.futureCards = [];
  window.GameData.futureCards.push.apply(window.GameData.futureCards, cards);
})();