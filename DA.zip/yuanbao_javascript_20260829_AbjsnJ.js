// 追加亚缇娜和玛利亚
if (typeof window.GameData !== 'undefined' && window.GameData.futureCharacters) {
  window.GameData.futureCharacters.push(
    {
      id: 'arthelina', name: '亚缇娜', gender: 'female', mother: '魅魔国', role: '狙击手',
      baseStats: { attack: 3, magic: 3, speed: 4, hp: 36, bloodlust: 1, handLimit: 4, drawPerTurn: 2, initialDraw: 2 },
      skills: ['snipe-target', 'charge-bullet'],
      battleEntranceLine: '让我看看敌人在哪。',
      evaluation: '狙击目标+蓄力子弹'
    },
    {
      id: 'maria', name: '玛利亚', gender: 'female', mother: '魅魔国', role: '支援兵',
      baseStats: { attack: 2, magic: 3, speed: 4, hp: 38, bloodlust: 2, handLimit: 3, drawPerTurn: 3, initialDraw: 1 },
      skills: ['divine-number', 'honor-blessing'],
      battleEntranceLine: '盖亚妮丝女神请你祝福我。',
      evaluation: '神数咒语+荣誉祝福'
    }
  );
}